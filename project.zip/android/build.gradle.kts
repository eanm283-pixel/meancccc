// 项目级构建脚本
plugins {
    id("com.android.application") version "8.2.2" apply false
}
