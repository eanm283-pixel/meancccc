plugins {
    id("com.android.application")
}

android {
    namespace = "com.timeline.diary"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.timeline.diary"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // 自己用直接装 debug 包就行；要正式签名的 release 包可以在这里加 signingConfigs
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.10.0")
    implementation("androidx.core:core:1.12.0")
}
