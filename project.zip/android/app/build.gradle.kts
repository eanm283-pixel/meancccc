plugins {
    id("com.android.application")
}

android {
    namespace = "com.timeline.diary"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.timeline.diary"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // 固定签名：签名一致才能覆盖安装（数据不丢）
    signingConfigs {
        create("stable") {
            val ks = rootProject.file("keystore.jks")
            if (ks.exists()) {
                storeFile = ks
                storePassword = "diary2026"
                keyAlias = "diary"
                keyPassword = "diary2026"
            }
        }
    }

    buildTypes {
        debug {
            val ks = rootProject.file("keystore.jks")
            if (ks.exists()) {
                signingConfig = signingConfigs.getByName("stable")
            }
        }
        release {
            isMinifyEnabled = false
            val ks = rootProject.file("keystore.jks")
            if (ks.exists()) {
                signingConfig = signingConfigs.getByName("stable")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.10.0")
    implementation("androidx.core:core:1.12.0")
}
