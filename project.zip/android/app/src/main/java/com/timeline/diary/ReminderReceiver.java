package com.timeline.diary;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** 到点弹出「往年今日」通知，并安排下一天 */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences p = ReminderScheduler.prefs(context);
        if (!p.getBoolean(ReminderScheduler.K_ENABLED, false)) return;

        String title = p.getString(ReminderScheduler.K_TITLE, "往年今日");
        String body = p.getString(ReminderScheduler.K_BODY, "看看往年这一天你写了什么");
        ReminderScheduler.show(context, title, body);
        ReminderScheduler.scheduleNext(context);
    }
}
