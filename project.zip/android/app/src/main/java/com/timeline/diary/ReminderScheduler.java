package com.timeline.diary;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import java.util.Calendar;

/** 每天固定时间提醒「往年今日」：用 AlarmManager 的窗口闹钟，不需要精确闹钟权限 */
final class ReminderScheduler {

    static final String PREFS = "timeline_reminder";
    static final String K_ENABLED = "enabled";
    static final String K_HOUR = "hour";
    static final String K_MINUTE = "minute";
    static final String K_TITLE = "title";
    static final String K_BODY = "body";
    private static final String CHANNEL_ID = "memories";
    private static final int REQ_ALARM = 1001;
    private static final int REQ_OPEN = 1002;
    private static final int NOTIFY_ID = 2001;

    private ReminderScheduler() {
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void save(Context c, boolean enabled, int hour, int minute, String title, String body) {
        prefs(c).edit()
                .putBoolean(K_ENABLED, enabled)
                .putInt(K_HOUR, hour)
                .putInt(K_MINUTE, minute)
                .putString(K_TITLE, title)
                .putString(K_BODY, body)
                .apply();
        if (enabled) {
            scheduleNext(c);
        } else {
            cancel(c);
        }
    }

    static void scheduleNext(Context c) {
        SharedPreferences p = prefs(c);
        if (!p.getBoolean(K_ENABLED, false)) {
            cancel(c);
            return;
        }
        int hour = p.getInt(K_HOUR, 21);
        int minute = p.getInt(K_MINUTE, 0);

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }

        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        // 允许 15 分钟误差，免去「精确闹钟」特殊权限
        am.setWindow(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), 15 * 60 * 1000L, alarmIntent(c));
    }

    static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(alarmIntent(c));
    }

    private static PendingIntent alarmIntent(Context c) {
        Intent i = new Intent(c, ReminderReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, REQ_ALARM, i, flags);
    }

    static void show(Context c, String title, String body) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "往年今日", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("每天提醒你看看往年这一天写下的日记");
            nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.putExtra("open_memories", true);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(c, REQ_OPEN, open, flags);

        Notification n = new NotificationCompat.Builder(c, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_memories)
                .setContentTitle(title != null ? title : "往年今日")
                .setContentText(body != null ? body : "看看往年这一天你写了什么")
                .setStyle(new NotificationCompat.BigTextStyle().bigText(
                        body != null ? body : "看看往年这一天你写了什么"))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build();

        try {
            nm.notify(NOTIFY_ID, n);
        } catch (SecurityException ignored) {
            // 用户没给通知权限
        }
    }
}
