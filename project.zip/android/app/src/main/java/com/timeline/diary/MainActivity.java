﻿package com.timeline.diary;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import java.io.ByteArrayOutputStream;
import android.widget.VideoView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.MediaController;
import android.util.Base64;
import android.media.MediaMetadataRetriever;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.view.ViewOutlineProvider;
import android.view.TextureView;
import android.view.Surface;
import android.os.Looper;
import android.os.Handler;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaPlayer;
import android.graphics.SurfaceTexture;
import android.graphics.Outline;
import android.graphics.Color;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * 人生时间线 —— 用一个全屏 WebView 承载本地网页应用。
 * 网页资源放在 assets/www 里，通过 WebViewAssetLoader 以 https 域名提供，
 * 这样 localStorage / IndexedDB / Service Worker 都能正常工作。
 */
public class MainActivity extends android.app.Activity {

    private static final String START_URL =
            "https://appassets.androidplatform.net/assets/www/index.html?native=1";
    private static final int REQ_FILE = 1001;
    private static final int REQ_CAMERA = 1002;
    private static final int REQ_BIG_VIDEO = 1003;
    private static final int REQ_ENTRY_VIDEO = 1004;

    private WebView webView;
    private ValueCallback<Uri[]> pendingCallback;
    private Uri cameraOutputUri;
    private boolean pageReady = false;
    private boolean pendingMemories = false;
    private int[] pendingInsets = null;
    private BroadcastReceiver ringerReceiver = null;

    /* 原生视频层（垫在网页下面，只在资料卡那块露出来） */
    private FrameLayout videoHolder = null;
    private TextureView videoTexture = null;
    private MediaPlayer nativePlayer = null;
    private Surface nativeSurface = null;
    private String pendingVideoPath = null;
    private boolean nativePrepared = false;
    private Handler tickHandler = null;
    private Runnable tickTask = null;

    /* 日记视频：全屏原生播放器 */
    private FrameLayout entryPlayer = null;
    private VideoView entryVideoView = null;
    private boolean entryPlayerVisible = false;
    private SeekBar entrySeek = null;
    private TextView entryTime = null;
    private TextView entryPlayBtn = null;
    private Handler entryTicker = null;
    private Runnable entryTickTask = null;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 全面屏沉浸式：内容延伸到状态栏 / 导航栏后面，背景图可以透出来
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
        getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setHorizontalScrollBarEnabled(false);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        buildVideoLayer(root);

        buildEntryPlayer(root);

        try {
            ringerReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    if (webView != null) {
                        webView.evaluateJavascript(
                                "window.__onSilentChanged&&window.__onSilentChanged(" + silentNow() + ")",
                                null);
                    }
                }
            };
            registerReceiver(ringerReceiver, new IntentFilter(AudioManager.RINGER_MODE_CHANGED_ACTION));
        } catch (Exception ignored) {
        }

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            int top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            applyInsetsToWeb(top, bottom);
            return insets;
        });

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String path = request.getUrl().getPath();
                if (path != null && path.startsWith("/localvideo/")) {
                    WebResourceResponse r = serveLocalVideo(path, request);
                    if (r != null) return r;
                }
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                pushInsets();
                if (pendingMemories) openMemoriesPage();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost();
                if ("appassets.androidplatform.net".equals(host)) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (pendingCallback != null) {
                    pendingCallback.onReceiveValue(null);
                }
                pendingCallback = callback;

                boolean capture = params != null && params.isCaptureEnabled();
                if (capture) {
                    return openCamera();
                }
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String mime = "image/*";
                String[] accepts = params != null ? params.getAcceptTypes() : null;
                if (accepts != null) {
                    for (String a : accepts) {
                        if (a != null && a.toLowerCase().indexOf("video") >= 0) {
                            mime = "video/*";
                            break;
                        }
                    }
                }
                intent.setType(mime);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(intent, "选择照片"), REQ_FILE);
                    return true;
                } catch (Exception e) {
                    pendingCallback = null;
                    toast("没有找到可用的相册应用");
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.loadUrl(START_URL);
        handleIntent(getIntent());
    }

    private boolean openCamera() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists() && !dir.mkdirs()) {
                throw new IllegalStateException("无法创建缓存目录");
            }
            File photo = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            cameraOutputUri = FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", photo);

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
            intent.setClipData(ClipData.newRawUri("photo", cameraOutputUri));
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, REQ_CAMERA);
            return true;
        } catch (Exception e) {
            pendingCallback = null;
            toast("无法打开相机：" + e.getMessage());
            return false;
        }
    }


    private void applyInsetsToWeb(int topPx, int bottomPx) {
        float d = getResources().getDisplayMetrics().density;
        pendingInsets = new int[]{Math.round(topPx / d), Math.round(bottomPx / d)};
        pushInsets();
    }

    private void pushInsets() {
        if (pendingInsets == null || webView == null || !pageReady) return;
        webView.evaluateJavascript(
                "window.__setInsets&&window.__setInsets(" + pendingInsets[0] + "," + pendingInsets[1] + ")",
                null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        pageReady = true;
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        if (!intent.getBooleanExtra("open_memories", false)) return;
        intent.removeExtra("open_memories");
        pendingMemories = true;
        openMemoriesPage();
    }

    private void openMemoriesPage() {
        if (webView == null || !pageReady) return;
        pendingMemories = false;
        webView.evaluateJavascript("try{location.hash='#/memories'}catch(e){}", null);
    }



    /* ---------------- 原生视频层 ---------------- */

    private void buildVideoLayer(FrameLayout root) {
        videoHolder = new FrameLayout(this);
        videoHolder.setVisibility(View.GONE);
        videoHolder.setBackgroundColor(0xFF000000);
        videoHolder.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                float r = view.getTag() instanceof Float ? (Float) view.getTag() : 32f;
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), r);
            }
        });
        videoHolder.setClipToOutline(true);

        videoTexture = new TextureView(this);
        videoHolder.addView(videoTexture, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(videoHolder, 0, new FrameLayout.LayoutParams(0, 0));

        videoTexture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                nativeSurface = new Surface(st);
                if (pendingVideoPath != null) openVideo(pendingVideoPath);
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                releaseSurface();
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture st) { }
        });
    }

    private void releaseSurface() {
        try { if (nativePlayer != null) { nativePlayer.release(); nativePlayer = null; } } catch (Exception ignored) { }
        try { if (nativeSurface != null) { nativeSurface.release(); nativeSurface = null; } } catch (Exception ignored) { }
        nativePrepared = false;
    }

    private void openVideo(final String ref) {
        pendingVideoPath = ref;
        if (videoTexture == null || !videoTexture.isAvailable()) return;
        try {
            releaseSurface();
            nativeSurface = new Surface(videoTexture.getSurfaceTexture());
            nativePlayer = new MediaPlayer();
            nativePlayer.setSurface(nativeSurface);
            nativePlayer.setLooping(true);
            if (ref != null && ref.contains("://")) {
                nativePlayer.setDataSource(this, Uri.parse(ref));
            } else {
                File f = new File(videoDir(), ref);
                nativePlayer.setDataSource(f.getAbsolutePath());
            }
            nativePlayer.setOnPreparedListener(mp -> {
                nativePrepared = true;
                mp.start();
                jsCall("window.__nvPrepared&&window.__nvPrepared(" + mp.getDuration() + ")");
                startTicker();
            });
            nativePlayer.setOnErrorListener((mp, what, extra) -> {
                jsCall("window.__nvError&&window.__nvError('" + what + ":" + extra + "')");
                return true;
            });
            nativePlayer.prepareAsync();
        } catch (Exception e) {
            jsCall("window.__nvError&&window.__nvError('open')");
        }
    }

    private void startTicker() {
        if (tickHandler == null) tickHandler = new Handler(Looper.getMainLooper());
        if (tickTask != null) tickHandler.removeCallbacks(tickTask);
        tickTask = new Runnable() {
            @Override
            public void run() {
                try {
                    if (nativePlayer != null && nativePrepared) {
                        jsCall("window.__nvPos&&window.__nvPos(" + nativePlayer.getCurrentPosition() + ")");
                    }
                } catch (Exception ignored) { }
                if (tickHandler != null && tickTask != null) tickHandler.postDelayed(tickTask, 400);
            }
        };
        tickHandler.postDelayed(tickTask, 400);
    }

    private void jsCall(final String code) {
        runOnUiThread(() -> {
            try { if (webView != null) webView.evaluateJavascript(code, null); } catch (Exception ignored) { }
        });
    }

    private void layoutVideoRect(int left, int top, int width, int height, int radiusDp,
                                 int vw, int vh, boolean visible) {
        if (videoHolder == null) return;
        int viewW = webView != null ? webView.getWidth() : 0;
        int viewH = webView != null ? webView.getHeight() : 0;
        float scale = 1f;
        if (vw > 0 && viewW > 0) scale = (float) viewW / (float) vw;
        else scale = getResources().getDisplayMetrics().density;

        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) videoHolder.getLayoutParams();
        lp.leftMargin = Math.round(left * scale);
        lp.topMargin = Math.round(top * scale);
        lp.width = Math.round(width * scale);
        lp.height = Math.round(height * scale);
        videoHolder.setLayoutParams(lp);
        videoHolder.setTag(radiusDp * scale);
        videoHolder.setVisibility(visible && width > 0 && height > 0 ? View.VISIBLE : View.GONE);
        videoHolder.invalidateOutline();
    }


    /* ---------------- 日记视频：全屏原生播放 ---------------- */

    private void buildEntryPlayer(FrameLayout root) {
        float d = getResources().getDisplayMetrics().density;

        entryPlayer = new FrameLayout(this);
        entryPlayer.setBackgroundColor(0xF0000000);
        entryPlayer.setVisibility(View.GONE);
        entryPlayer.setOnClickListener(v -> hideEntryPlayer());

        /* 卡片：圆角 + 黑底，和网页播放器一致的观感 */
        FrameLayout card = new FrameLayout(this);
        card.setBackgroundColor(0xFF000000);
        card.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), 22 * d);
            }
        });
        card.setClipToOutline(true);
        card.setOnClickListener(v -> { });  /* 点卡片不关闭 */

        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        clp.gravity = android.view.Gravity.CENTER;
        clp.leftMargin = Math.round(12 * d);
        clp.rightMargin = Math.round(12 * d);
        entryPlayer.addView(card, clp);

        entryVideoView = new VideoView(this);
        card.addView(entryVideoView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, Math.round(240 * d)));

        /* 中央播放/暂停 */
        entryPlayBtn = new TextView(this);
        entryPlayBtn.setText("▶");
        entryPlayBtn.setTextSize(26);
        entryPlayBtn.setTextColor(0xFFFFFFFF);
        entryPlayBtn.setGravity(android.view.Gravity.CENTER);
        entryPlayBtn.setBackgroundColor(0x66000000);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(Math.round(64 * d), Math.round(64 * d));
        plp.gravity = android.view.Gravity.CENTER;
        entryPlayBtn.setLayoutParams(plp);
        card.addView(entryPlayBtn);
        entryPlayBtn.setOnClickListener(v -> toggleEntryPlay());

        /* 底部：时间 + 进度条 */
        FrameLayout bottom = new FrameLayout(this);
        bottom.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, Math.round(56 * d));
        blp.gravity = android.view.Gravity.BOTTOM;
        card.addView(bottom, blp);

        entryTime = new TextView(this);
        entryTime.setTextColor(0xFFFFFFFF);
        entryTime.setTextSize(12);
        entryTime.setText("0:00 / 0:00");
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        tlp.leftMargin = Math.round(14 * d);
        tlp.topMargin = Math.round(6 * d);
        entryTime.setLayoutParams(tlp);
        bottom.addView(entryTime);

        entrySeek = new SeekBar(this);
        entrySeek.setMax(1000);
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        slp.gravity = android.view.Gravity.BOTTOM;
        slp.leftMargin = Math.round(10 * d);
        slp.rightMargin = Math.round(10 * d);
        slp.bottomMargin = Math.round(4 * d);
        entrySeek.setLayoutParams(slp);
        bottom.addView(entrySeek);

        entrySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser) {
                    int dur = entryVideoView.getDuration();
                    if (dur > 0) entryVideoView.seekTo(dur * progress / 1000);
                }
            }

            @Override public void onStartTrackingTouch(SeekBar sb) { }

            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });

        root.addView(entryPlayer, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private String fmtTime(int ms) {
        if (ms < 0) ms = 0;
        int total = ms / 1000;
        return String.format(java.util.Locale.US, "%d:%02d", total / 60, total % 60);
    }

    private void toggleEntryPlay() {
        try {
            if (entryVideoView == null) return;
            if (entryVideoView.isPlaying()) {
                entryVideoView.pause();
                if (entryPlayBtn != null) entryPlayBtn.setText("▶");
            } else {
                entryVideoView.start();
                if (entryPlayBtn != null) entryPlayBtn.setText("❚❚");
            }
        } catch (Exception ignored) { }
    }

    private void startEntryTicker() {
        if (entryTicker == null) entryTicker = new Handler(Looper.getMainLooper());
        if (entryTickTask != null) entryTicker.removeCallbacks(entryTickTask);
        entryTickTask = new Runnable() {
            @Override
            public void run() {
                try {
                    if (entryPlayerVisible && entryVideoView != null) {
                        int pos = entryVideoView.getCurrentPosition();
                        int dur = entryVideoView.getDuration();
                        if (entryTime != null) entryTime.setText(fmtTime(pos) + " / " + fmtTime(dur));
                        if (entrySeek != null && dur > 0) entrySeek.setProgress(pos * 1000 / dur);
                        if (entryPlayBtn != null) entryPlayBtn.setText(entryVideoView.isPlaying() ? "❚❚" : "▶");
                    }
                } catch (Exception ignored) { }
                if (entryTicker != null && entryTickTask != null) entryTicker.postDelayed(entryTickTask, 350);
            }
        };
        entryTicker.postDelayed(entryTickTask, 200);
    }

    private void showEntryPlayer(String ref) {
        if (entryPlayer == null || entryVideoView == null) return;
        entryPlayerVisible = true;
        entryPlayer.setVisibility(View.VISIBLE);
        if (entryPlayBtn != null) entryPlayBtn.setText("▶");

        if (ref != null && ref.contains("://")) {
            entryVideoView.setVideoURI(Uri.parse(ref));
        } else {
            File f = new File(videoDir(), ref);
            if (!f.exists()) { toast("视频文件不见了"); hideEntryPlayer(); return; }
            entryVideoView.setVideoPath(f.getAbsolutePath());
        }

        entryVideoView.setOnPreparedListener(mp -> {
            mp.setLooping(false);
            entryVideoView.start();
            if (entryPlayBtn != null) entryPlayBtn.setText("❚❚");
            startEntryTicker();
        });
        entryVideoView.setOnErrorListener((mp, what, extra) -> {
            toast("这个视频播不了");
            hideEntryPlayer();
            return true;
        });
    }

    private void hideEntryPlayer() {
        entryPlayerVisible = false;
        try { if (entryTicker != null && entryTickTask != null) entryTicker.removeCallbacks(entryTickTask); } catch (Exception ignored) { }
        if (entryPlayer != null) entryPlayer.setVisibility(View.GONE);
        try {
            if (entryVideoView != null) { entryVideoView.pause(); entryVideoView.stopPlayback(); }
        } catch (Exception ignored) { }
    }

    private void openEntryVideoPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        try {
            startActivityForResult(i, REQ_ENTRY_VIDEO);
        } catch (Exception e) {
            toast("打不开文件选择器");
        }
    }



    /* ---------------- 本地大视频（GB 级）：Range 流式播放 ---------------- */







    /* 检查本机能否解码这个视频（避免导进来黑屏） */


    private String makePoster(Uri uri) {
        MediaMetadataRetriever r = null;
        try {
            r = new MediaMetadataRetriever();
            r.setDataSource(this, uri);
            String durStr = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            long durMs = durStr == null ? 0 : Long.parseLong(durStr);
            /* 默认取 15% 处，避开黑场片头 */
            long atMs = (long) (durMs * 0.15);
            if (atMs < 300) atMs = 300;
            if (atMs > 4000) atMs = 4000;
            long atUs = atMs * 1000;
            Bitmap bmp = r.getFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (bmp == null) return "";
            int w = bmp.getWidth();
            int h = bmp.getHeight();
            float scale = Math.min(1f, 560f / Math.max(w, h));
            Bitmap small = Bitmap.createScaledBitmap(bmp, Math.max(1, (int) (w * scale)),
                    Math.max(1, (int) (h * scale)), true);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            small.compress(Bitmap.CompressFormat.JPEG, 72, out);
            String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            return "data:image/jpeg;base64," + b64;
        } catch (Exception e) {
            return "";
        } finally {
            try { if (r != null) r.release(); } catch (Exception ignored) { }
        }
    }

    /* 抽取若干帧，用于选择视频封面（首帧可能是黑的） */
    private void extractFramesAsync(final String uriStr, final int count) {
        new Thread(() -> {
            MediaMetadataRetriever r = null;
            StringBuilder out = new StringBuilder("[");
            try {
                r = new MediaMetadataRetriever();
                r.setDataSource(MainActivity.this, Uri.parse(uriStr));
                String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                long durMs = d == null ? 0 : Long.parseLong(d);
                if (durMs <= 0) durMs = 5000;
                int n = Math.max(4, Math.min(12, count));
                for (int i = 0; i < n; i++) {
                    /* 从 6% 到 94%，避开纯黑的首尾帧 */
                    long atMs = (long) (durMs * (0.06 + 0.88 * i / (n - 1.0)));
                    Bitmap bmp = r.getFrameAtTime(atMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    String b64 = "";
                    if (bmp != null) {
                        int w = bmp.getWidth();
                        int h = bmp.getHeight();
                        float sc = Math.min(1f, 360f / Math.max(w, h));
                        Bitmap small = Bitmap.createScaledBitmap(bmp,
                                Math.max(1, (int) (w * sc)), Math.max(1, (int) (h * sc)), true);
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        small.compress(Bitmap.CompressFormat.JPEG, 68, bos);
                        b64 = "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
                    }
                    if (i > 0) out.append(",");
                    out.append("'").append(b64).append("'");
                }
                out.append("]");
                final String payload = out.toString();
                final String ref = uriStr.replace("'", "");
                runOnUiThread(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript(
                                "window.__onEntryFrames&&window.__onEntryFrames('" + ref + "'," + payload + ")", null);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("截取画面失败"));
            } finally {
                try { if (r != null) r.release(); } catch (Exception ignored) { }
            }
        }).start();
    }

    private void importEntryVideo(final Uri uri) {
        final String unsupported = checkVideoSupport(uri);
        if (unsupported != null) {
            toast(unsupported + "，请换成 H.264 的 MP4");
            jsCall("window.__onBigVideoRejected&&window.__onBigVideoRejected('" + unsupported + "')");
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        toast("正在读取视频…");
        new Thread(() -> {
            String poster = makePoster(uri);
            final String ref = uri.toString();
            final String safePoster = poster == null ? "" : poster.replace("'", "");
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.evaluateJavascript(
                            "window.__onEntryVideo&&window.__onEntryVideo('" + ref + "','" + safePoster + "')",
                            null);
                }
            });
        }).start();
    }


    /* ---------------- 本地大视频（GB 级）：Range 流式播放 ---------------- */

    private File videoDir() {
        File d = new File(getFilesDir(), "videos");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private WebResourceResponse serveLocalVideo(String path, WebResourceRequest request) {
        try {
            String id = path.substring(path.lastIndexOf('/') + 1);
            if (id.length() == 0 || id.contains("..")) return null;
            File f = new File(videoDir(), id);
            if (!f.exists() || !f.isFile()) return null;
            long total = f.length();
            long start = 0;
            long end = total - 1;
            boolean partial = false;

            String range = null;
            try {
                Map<String, String> h = request.getRequestHeaders();
                if (h != null) range = h.get("Range");
            } catch (Exception ignored) {
            }
            if (range != null && range.contains("=")) {
                String spec = range.substring(range.indexOf('=') + 1);
                int dash = spec.indexOf('-');
                if (dash >= 0) {
                    String a = spec.substring(0, dash).trim();
                    String b = spec.substring(dash + 1).trim();
                    if (a.length() > 0) start = Long.parseLong(a);
                    if (b.length() > 0) end = Long.parseLong(b);
                    if (start < 0) start = 0;
                    if (end >= total) end = total - 1;
                    if (end < start) return null;
                    partial = true;
                }
            }

            long length = end - start + 1;
            RandomAccessFile raf = new RandomAccessFile(f, "r");
            raf.seek(start);

            Map<String, String> headers = new HashMap<>();
            headers.put("Accept-Ranges", "bytes");
            headers.put("Content-Length", String.valueOf(length));
            headers.put("Cache-Control", "no-store");
            if (partial) {
                headers.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
            }
            int status = partial ? 206 : 200;
            String reason = partial ? "Partial Content" : "OK";
            return new WebResourceResponse("video/mp4", null, status, reason, headers,
                    new BoundedStream(raf, length));
        } catch (Exception e) {
            return null;
        }
    }

    private static class BoundedStream extends InputStream {
        private final RandomAccessFile raf;
        private long remain;

        BoundedStream(RandomAccessFile raf, long length) {
            this.raf = raf;
            this.remain = length;
        }

        @Override
        public int read() {
            try {
                if (remain <= 0) return -1;
                int b = raf.read();
                if (b >= 0) remain--;
                return b;
            } catch (Exception e) {
                return -1;
            }
        }

        @Override
        public int read(byte[] buf, int off, int len) {
            try {
                if (remain <= 0) return -1;
                int n = raf.read(buf, off, (int) Math.min(len, remain));
                if (n > 0) remain -= n;
                return n;
            } catch (Exception e) {
                return -1;
            }
        }

        @Override
        public void close() {
            try { raf.close(); } catch (Exception ignored) { }
        }
    }

    private void openBigVideoPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        try {
            startActivityForResult(i, REQ_BIG_VIDEO);
        } catch (Exception e) {
            toast("打不开文件选择器");
        }
    }

    private String queryName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        if (name == null) name = "video.mp4";
        return name;
    }


    /* 检查本机能否解码这个视频（避免导进来黑屏） */
    private String checkVideoSupport(Uri uri) {
        MediaExtractor ex = null;
        try {
            ex = new MediaExtractor();
            ex.setDataSource(this, uri, null);
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime == null || !mime.startsWith("video/")) continue;
                boolean hasDecoder = false;
                MediaCodecList list = new MediaCodecList(MediaCodecList.REGULAR_CODECS);
                for (MediaCodecInfo info : list.getCodecInfos()) {
                    if (info.isEncoder()) continue;
                    for (String t : info.getSupportedTypes()) {
                        if (t.equalsIgnoreCase(mime)) { hasDecoder = true; break; }
                    }
                    if (hasDecoder) break;
                }
                if (!hasDecoder) {
                    if (mime.equals("video/av01")) return "本机不支持 AV1 编码";
                    if (mime.equals("video/avc")) return "本机不支持 H.264 编码";
                    if (mime.equals("video/hevc")) return "本机不支持 H.265 编码";
                    return "本机不支持 " + mime;
                }
                return null;
            }
        } catch (Exception e) {
            return null;
        } finally {
            try { if (ex != null) ex.release(); } catch (Exception ignored) { }
        }
        return null;
    }

    private void importBigVideo(final Uri uri) {
        final String name = queryName(uri);
        final String unsupported = checkVideoSupport(uri);
        if (unsupported != null) {
            toast(unsupported + "，请换成 H.264 的 MP4");
            jsCall("window.__onBigVideoRejected&&window.__onBigVideoRejected('" + unsupported + "')");
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        toast("正在读取视频…");
        new Thread(() -> {
            String poster = makePoster(uri);
            final String ref = uri.toString();
            final String safePoster = poster == null ? "" : poster.replace("'", "");
            final String safeName = name.replace("'", "");
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.evaluateJavascript(
                            "window.__onBigVideo&&window.__onBigVideo('" + ref + "','" + safeName + "','" + safePoster + "')",
                            null);
                }
            });
        }).start();
    }


    private void deleteBigVideoFile(String id) {
        try {
            if (id == null || id.contains("..") || id.contains("/")) return;
            File f = new File(videoDir(), id);
            if (f.exists()) f.delete();
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_ENTRY_VIDEO) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                importEntryVideo(data.getData());
            }
            return;
        }
        if (requestCode == REQ_BIG_VIDEO) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                importBigVideo(data.getData());
            }
            return;
        }
        if (requestCode == REQ_FILE) {
            if (pendingCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null) {
                    int n = clip.getItemCount();
                    result = new Uri[n];
                    for (int i = 0; i < n; i++) {
                        result[i] = clip.getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            pendingCallback.onReceiveValue(result);
            pendingCallback = null;
        } else if (requestCode == REQ_CAMERA) {
            if (pendingCallback == null) return;
            Uri[] result = (resultCode == RESULT_OK && cameraOutputUri != null)
                    ? new Uri[]{cameraOutputUri} : null;
            pendingCallback.onReceiveValue(result);
            pendingCallback = null;
            cameraOutputUri = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (entryPlayerVisible) { hideEntryPlayer(); return; }
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{return window.__handleBack?window.__handleBack():false}catch(e){return false}})()",
                value -> {
                    if ("true".equals(value)) return;
                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        finish();
                    }
                });
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3001);
        }
    }

    private boolean silentNow() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            return am != null && am.getRingerMode() != AudioManager.RINGER_MODE_NORMAL;
        } catch (Exception e) {
            return false;
        }
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    /** 给网页用的原生能力：把导出的备份写到「下载」目录 */
    private class Bridge {
        @JavascriptInterface
        public void scheduleDailyReminder(boolean enabled, String time, String title, String body) {
            int hour = 21;
            int minute = 0;
            try {
                String[] parts = String.valueOf(time).split(":");
                hour = Integer.parseInt(parts[0].trim());
                minute = Integer.parseInt(parts[1].trim());
            } catch (Exception ignored) {
            }
            ReminderScheduler.save(MainActivity.this, enabled, hour, minute, title, body);
            if (enabled) runOnUiThread(() -> ensureNotificationPermission());
        }
        @JavascriptInterface
        public boolean isSilentMode() {
            return silentNow();
        }


        @JavascriptInterface
        public void setVideoRect(int left, int top, int width, int height, int radiusDp,
                                 int vw, int vh, boolean visible) {
            try {
                runOnUiThread(() -> layoutVideoRect(left, top, width, height, radiusDp, vw, vh, visible));
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void openNativeVideo(String fileName) {
            runOnUiThread(() -> openVideo(fileName));
        }

        @JavascriptInterface
        public void playNativeVideo() {
            runOnUiThread(() -> {
                try { if (nativePlayer != null && nativePrepared) nativePlayer.start(); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void pauseNativeVideo() {
            runOnUiThread(() -> {
                try { if (nativePlayer != null && nativePrepared) nativePlayer.pause(); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void seekNativeVideo(int deltaMs) {
            runOnUiThread(() -> {
                try {
                    if (nativePlayer != null && nativePrepared) {
                        int t = nativePlayer.getCurrentPosition() + deltaMs;
                        if (t < 0) t = 0;
                        if (t > nativePlayer.getDuration() - 150) t = Math.max(0, nativePlayer.getDuration() - 150);
                        nativePlayer.seekTo(t);
                        jsCall("window.__nvPos&&window.__nvPos(" + t + ")");
                    }
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void muteNativeVideo(boolean muted) {
            runOnUiThread(() -> {
                try {
                    if (nativePlayer != null) {
                        float v = muted ? 0f : 1f;
                        nativePlayer.setVolume(v, v);
                    }
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void hideNativeVideo() {
            runOnUiThread(() -> {
                if (videoHolder != null) videoHolder.setVisibility(View.GONE);
                try { if (nativePlayer != null) nativePlayer.pause(); } catch (Exception ignored) { }
            });
        }


        @JavascriptInterface
        public void extractFrames(String uriStr, int count) {
            try {
                extractFramesAsync(uriStr, count);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void pickEntryVideo() {
            try {
                runOnUiThread(() -> openEntryVideoPicker());
            } catch (Exception e) {
                jsCall("window.__onBigVideoRejected&&window.__onBigVideoRejected('打开相册失败')");
            }
        }

        @JavascriptInterface
        public void playEntryVideo(String fileName) {
            try {
                runOnUiThread(() -> showEntryPlayer(fileName));
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void hideEntryVideo() {
            try {
                runOnUiThread(() -> hideEntryPlayer());
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void pickBigVideo() {
            runOnUiThread(() -> openBigVideoPicker());
        }

        @JavascriptInterface
        public void deleteBigVideo(String id) {
            deleteBigVideoFile(id);
        }

        @JavascriptInterface
        public void setBars(String colorHex, boolean lightIcons) {
            runOnUiThread(() -> {
                try {
                    android.view.View decor = getWindow().getDecorView();
                    int flags = decor.getSystemUiVisibility();
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (lightIcons) flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        else flags &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    }
                    if (Build.VERSION.SDK_INT >= 26) {
                        if (lightIcons) flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                        else flags &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    }
                    decor.setSystemUiVisibility(flags);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void saveBackup(String filename, String content) {
            try {
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver()
                            .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IllegalStateException("无法创建文件");
                    OutputStream out = getContentResolver().openOutputStream(uri);
                    if (out == null) throw new IllegalStateException("无法写入文件");
                    out.write(bytes);
                    out.close();

                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                    toast("备份已保存到「下载」：" + filename);
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
                    if (dir == null) dir = getFilesDir();
                    if (!dir.exists()) dir.mkdirs();
                    File target = new File(dir, filename);
                    FileOutputStream fos = new FileOutputStream(target);
                    fos.write(bytes);
                    fos.close();
                    toast("备份已保存到：" + target.getAbsolutePath());
                }
            } catch (Exception e) {
                toast("保存失败：" + e.getMessage());
            }
        }
    }

    @Override
    protected void onDestroy() {
        try { if (ringerReceiver != null) unregisterReceiver(ringerReceiver); } catch (Exception ignored) { }
        ringerReceiver = null;
        try { if (tickHandler != null && tickTask != null) tickHandler.removeCallbacks(tickTask); } catch (Exception ignored) { }
        releaseSurface();
        hideEntryPlayer();
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        try {
            if (webView != null) webView.evaluateJavascript("window.__onAppPause&&window.__onAppPause()", null);
        } catch (Exception ignored) { }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (webView != null) webView.evaluateJavascript("window.__onAppResume&&window.__onAppResume()", null);
        } catch (Exception ignored) { }
    }

}
