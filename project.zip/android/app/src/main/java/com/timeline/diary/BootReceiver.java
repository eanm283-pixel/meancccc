package com.timeline.diary;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 重启手机后重新安排提醒（AlarmManager 的闹钟重启会丢失） */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        if (ReminderScheduler.prefs(context).getBoolean(ReminderScheduler.K_ENABLED, false)) {
            ReminderScheduler.scheduleNext(context);
        }
    }
}
