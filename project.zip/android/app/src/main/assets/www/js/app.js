﻿/* 人生时间线 · 主程序 */
(function (global) {
  'use strict';

  var U = UI;
  var icon = U.icon;
  var esc = U.esc;

  var App = {
    state: null,
    tab: 'all',
    query: '',
    cal: null,
    draft: null,
    screens: {},
    actions: {},
    route: '',
    params: {}
  };

  /* ---------------- 主题 ---------------- */
  var ACCENTS = {
    peach: { a: '#ff8153', s: '#ffe3d7', i: '#e2673c' },
    sage: { a: '#7fb69f', s: '#dcece4', i: '#4f9078' },
    lilac: { a: '#a98fdd', s: '#ece4fb', i: '#8268bd' },
    sky: { a: '#7aa9d8', s: '#e2eefb', i: '#527fab' },
    rose: { a: '#ef8fa8', s: '#ffe4ea', i: '#cf6383' }
  };

  function applySettings() {
    var s = App.state.settings || {};
    var ac = ACCENTS[s.accent] || ACCENTS.peach;
    var root = document.documentElement;
    root.style.setProperty('--accent', ac.a);
    root.style.setProperty('--accent-soft', ac.s);
    root.style.setProperty('--accent-ink', ac.i);
    var scale = s.fontScale || 1;
    root.style.setProperty('--font-size', (15 * scale).toFixed(2) + 'px');
  }

  /* ---------------- 数据操作 ---------------- */
  function save() {
    applySettings();
    var p = Store.save(App.state);
    try { syncReminder(); } catch (e) { }
    return p;
  }

  function entriesSorted() {
    return App.state.entries.slice().sort(function (a, b) {
      var ka = (a.date || '') + ' ' + (a.time || '');
      var kb = (b.date || '') + ' ' + (b.time || '');
      return ka < kb ? 1 : ka > kb ? -1 : 0;
    });
  }

  function getEntry(id) {
    for (var i = 0; i < App.state.entries.length; i++) {
      if (App.state.entries[i].id === id) return App.state.entries[i];
    }
    return null;
  }

  function events() {
    return App.state.entries.filter(function (e) { return e.type === 'event'; })
      .sort(function (a, b) { return (a.date || '') < (b.date || '') ? 1 : -1; });
  }

  function countDays() {
    var set = {};
    App.state.entries.forEach(function (e) { if (e.date) set[e.date] = 1; });
    return Object.keys(set).length;
  }

  function distinctDates() {
    var map = {};
    App.state.entries.forEach(function (e) {
      if (!e.date) return;
      map[e.date] = map[e.date] || [];
      map[e.date].push(e);
    });
    Object.keys(map).forEach(function (d) {
      map[d].sort(function (a, b) { return (a.time || '') < (b.time || '') ? 1 : -1; });
    });
    return map;
  }

  /* ---------------- 路由 ---------------- */
  function parseHash() {
    var raw = String(location.hash || '').replace(/^#/, '');
    raw = raw.split('?')[0];
    if (!raw) return { name: 'home', params: {} };
    var parts = raw.split('/').filter(Boolean);
    var name = parts[0] || 'home';
    var params = {};
    if (name === 'entry' || name === 'edit') params.id = parts[1] || '';
    if (name === 'calendar') params.date = parts[1] || '';
    return { name: name, params: params };
  }

  function navigate(path, replace) {
    var hash = '#' + path;
    if (location.hash === hash) { render(); return; }
    if (replace) location.replace(hash);
    else location.hash = hash;
  }

  function back() {
    if (history.length > 1) history.back();
    else navigate('/');
  }

  function render() {
    var r = parseHash();
    U.closeSheet();
    closeDrawer();
    App.route = r.name;
    App.params = r.params;
    var screen = App.screens[r.name] || App.screens.home;
    var app = U.el('app');
    document.title = appTitle();
    app.innerHTML = screen(r.params) || '';
    app.scrollTop = 0;
    window.scrollTo(0, 0);
    if (App.afterRender) App.afterRender(r.name, r.params);
  }

  /* ---------------- 首页 ---------------- */
  /* ---------------- 往年今日 ---------------- */
  function trimText(s, n) {
    s = String(s == null ? '' : s).replace(/\s+/g, ' ');
    return s.length > n ? s.slice(0, n) + '…' : s;
  }

  function memoriesFor(dateStr) {
    var date = dateStr || Store.dateStr();
    var md = String(date).slice(5);
    return App.state.entries.filter(function (e) {
      return String(e.date || '').slice(5) === md && e.date !== date;
    }).sort(function (a, b) { return (a.date || '') < (b.date || '') ? 1 : -1; });
  }

  function yearsAgo(dateStr) {
    return new Date().getFullYear() - Number(String(dateStr).slice(0, 4));
  }

  function memoryBanner() {
    var list = memoriesFor();
    if (!list.length) return '';
    var first = list[0];
    return '<div class="memory-banner tapable" data-act="open-memories">' +
      '<span class="mb-ico">🕰️</span>' +
      '<span class="mb-tx"><span class="t">往年今日 · ' + list.length + ' 条</span>' +
      '<span class="s">' + yearsAgo(first.date) + ' 年前的今天：' + esc(trimText(first.title || first.content, 16)) + '</span></span>' +
      '<span class="chev">' + icon('chev', 'sm') + '</span></div>';
  }

  App.screens.memories = function () {
    var list = memoriesFor();
    var head = '<header class="topbar">' +
      '<div class="slot left"><button class="icon-btn plain" data-act="back" aria-label="返回">' + icon('back') + '</button></div>' +
      '<div class="title">往年今日</div>' +
      '<div class="slot"><button class="icon-btn plain" data-act="nav" data-to="/settings" aria-label="提醒设置">' + icon('bell') + '</button></div>' +
      '</header>';

    if (!list.length) {
      return '<div class="screen">' + head +
        '<div class="empty" style="margin-top:36px"><div class="emoji">🕰️</div>' +
        '<div class="t">往年的今天还没有记录</div>' +
        '<div class="s">今天写一条，明年的今天就会出现在这里</div>' +
        '<button class="btn primary" data-act="new">写今天</button></div>' +
        '<div class="detail-foot">打开「高级设置 → 往年今日提醒」，每天到点会提醒你回来看看</div></div>';
    }

    var groups = {}, order = [];
    list.forEach(function (e) {
      var y = String(e.date).slice(0, 4);
      if (!groups[y]) { groups[y] = []; order.push(y); }
      groups[y].push(e);
    });
    var body = order.map(function (y) {
      var items = groups[y];
      return '<div class="day-head"><span class="d">' + yearsAgo(items[0].date) + ' 年前的今天</span>' +
        '<span class="rel">' + U.cnDate(items[0].date) + ' ' + U.weekday(items[0].date) + '</span>' +
        '<span class="n">' + items.length + ' 条</span></div>' +
        items.map(function (e) { return entryCard(e); }).join('');
    }).join('');

    return '<div class="screen">' + head + '<div class="timeline">' + body + '</div>' +
      '<div class="detail-foot">想每天都收到提醒？去「高级设置 → 往年今日提醒」设置时间</div></div>';
  };

  /* 每天第一次打开时的「往年今日」弹层 */
  function maybeShowMemories() {
    var s = App.state.settings || {};
    var r = s.reminder || {};
    if (!r.enabled) return;
    if (s.lastMemoryShown === Store.dateStr()) return;
    if (App.route === 'memories') return;
    var list = memoriesFor();
    if (!list.length) return;
    s.lastMemoryShown = Store.dateStr();
    save();
    U.openSheet(
      '<div class="sheet-head"><div class="t">往年今日</div>' +
      '<button class="x" data-act="close-sheet" aria-label="关闭">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body">' +
      list.slice(0, 3).map(function (e) {
        return '<div class="memory-row tapable" data-act="open-entry" data-id="' + esc(e.id) + '">' +
          '<div class="y">' + yearsAgo(e.date) + ' 年前</div>' +
          '<div class="t">' + esc(e.title || '无标题') + '</div>' +
          (e.content ? '<div class="s">' + esc(trimText(e.content, 56)) + '</div>' : '') +
          '</div>';
      }).join('') +
      '<button class="btn primary block" style="margin-top:10px" data-act="open-memories">查看全部 ' + list.length + ' 条</button>' +
      '</div>');
  }

  /* 提醒：原生走 AndroidBridge，网页走 Notification */
  function reminderText() {
    var list = memoriesFor();
    if (!list.length) return '今天还没有往年的记录，来写一条，明年的今天就能看到。';
    var first = list[0];
    return yearsAgo(first.date) + ' 年前的今天：' + trimText(first.title || first.content, 40) +
      (list.length > 1 ? '（还有 ' + (list.length - 1) + ' 条）' : '');
  }

  function notifyNow(title, body) {
    try {
      if (!('Notification' in global) || Notification.permission !== 'granted') return;
      if (navigator.serviceWorker && navigator.serviceWorker.controller) {
        navigator.serviceWorker.ready.then(function (reg) {
          reg.showNotification(title, {
            body: body, tag: 'memories', icon: 'icons/icon-192.png',
            badge: 'icons/favicon.png', data: { url: './index.html#/memories' }
          });
        }).catch(function () { });
      } else {
        new Notification(title, { body: body, icon: 'icons/icon-192.png' });
      }
    } catch (e) { }
  }

  var webTimer = null;

  function scheduleWebReminder(r) {
    if (webTimer) { clearTimeout(webTimer); webTimer = null; }
    if (!r || !r.enabled) return;
    if (!('Notification' in global) || Notification.permission !== 'granted') return;
    var parts = String(r.time || '21:00').split(':');
    var t = new Date();
    t.setHours(Number(parts[0]) || 21, Number(parts[1]) || 0, 0, 0);
    var ms = t.getTime() - Date.now();
    if (ms <= 0) ms += 86400000;
    if (ms > 8 * 3600 * 1000) return; // 太远就不挂，等下次打开再算
    webTimer = setTimeout(function () {
      notifyNow('往年今日', reminderText());
      scheduleWebReminder(r);
    }, ms);
  }

  function syncReminder() {
    var r = (App.state.settings && App.state.settings.reminder) || {};
    var body = reminderText();
    if (global.AndroidBridge && global.AndroidBridge.scheduleDailyReminder) {
      try {
        global.AndroidBridge.scheduleDailyReminder(!!r.enabled, r.time || '21:00', '往年今日', body);
      } catch (e) { }
    }
    scheduleWebReminder(r);
  }

  function requestNotifyPermission() {
    if (!('Notification' in global)) return;
    if (Notification.permission === 'default') {
      try { Notification.requestPermission(); } catch (e) { }
    }
  }

  var TABS = [
    { k: 'all', label: '全部' },
    { k: 'diary', label: '日记' },
    { k: 'event', label: '事件' },
    { k: 'world', label: '世界' }
  ];

  function filteredEntries() {
    var list = entriesSorted();
    var q = App.query.trim().toLowerCase();
    if (App.tab === 'diary') list = list.filter(function (e) { return e.type !== 'event'; });
    if (App.tab === 'event') list = list.filter(function (e) { return e.type === 'event'; });
    if (q) {
      list = list.filter(function (e) {
        return ((e.title || '') + ' ' + (e.content || '') + ' ' + (e.tags || []).join(' ') + ' ' + (e.notebook || '')).toLowerCase().indexOf(q) >= 0;
      });
    }
    return list;
  }

  function moodEmoji(m) {
    return ['😄', '🙂', '😌', '😔', '😤'][Number(m) || 0] || '🙂';
  }

  function entryCard(e, opts) {
    opts = opts || {};
    var photo = (e.photos && e.photos[0])
      ? '<div class="entry-photo"><img src="' + esc(e.photos[0]) + '" alt="" loading="lazy"></div>' : '';
    var tags = (e.tags || []).map(function (t) { return '<span class="tag">' + esc(t) + '</span>'; }).join('');
    var badge = e.type === 'event' ? '<span class="badge event">事件</span>' : '<span class="badge">日记</span>';
    var rail = opts.noRail ? '' :
      '<div class="rail">' + badge + '<div class="line"></div></div>';
    return '<article class="entry' + (opts.noRail ? ' flat' : '') + ' tapable" data-act="open-entry" data-id="' + esc(e.id) + '">' +
      rail +
      '<div class="entry-body">' +
        '<div class="entry-line">' +
          '<span class="entry-title">' + esc(e.title || '无标题') + '</span>' +
          '<span class="time">' + esc(e.time || '') + '</span>' +
          '<span class="mood-face">' + esc(e.emoji || moodEmoji(e.mood)) + '</span>' +
        '</div>' +
        (e.content ? '<div class="entry-text">' + esc(e.content) + '</div>' : '') +
        photo +
        (tags ? '<div class="entry-foot">' + tags + '</div>' : '') +
      '</div></article>';
  }

  function timelineHtml(list) {
    if (!list.length) {
      return '<div class="empty"><div class="emoji">🕊️</div><div class="t">' +
        (App.query ? '没有找到相关记录' : '还没有记录') + '</div><div class="s">' +
        (App.query ? '换个关键词试试' : '从一件小事开始吧') + '</div>' +
        (App.query ? '' : '<button class="btn primary" data-act="new">写第一条</button>') + '</div>';
    }
    var groups = {}, order = [];
    list.forEach(function (e) {
      if (!groups[e.date]) { groups[e.date] = []; order.push(e.date); }
      groups[e.date].push(e);
    });
    return order.map(function (d) {
      var items = groups[d].map(function (e) { return entryCard(e); }).join('');
      var diff = Store.dayDiff(d);
      var rel = diff === 0 ? '今天' : diff === 1 ? '昨天' : diff === -1 ? '明天' : diff + ' 天前';
      return '<div class="day-head"><span class="d">' + U.cnDate(d) + '</span>' +
        '<span class="rel' + (diff === 0 ? ' today' : '') + '">' + rel + '</span>' +
        '<span class="n">' + groups[d].length + ' 条</span></div>' + items;
    }).join('');
  }

  /* 世界上的今天 */
  /* 附近几天的历史事件（当天条目少时补足） */
  function nearbyWorld(d, limit) {
    var out = [];
    for (var off = 1; off <= 10 && out.length < limit; off++) {
      var signs = [1, -1];
      for (var i = 0; i < signs.length && out.length < limit; i++) {
        var day = new Date(d.getFullYear(), d.getMonth(), d.getDate() + signs[i] * off);
        var ds = Store.dateStr(day);
        var list = World.forDate(ds);
        for (var j = 0; j < list.length && out.length < limit; j++) {
          out.push({ date: ds, item: list[j] });
        }
      }
    }
    return out;
  }

  function worldView() {
    var today = Store.dateStr();
    var date = App.worldDate || today;
    var d = Store.parseDate(date);
    var list = (global.World ? World.forDate(date) : []);
    var isToday = date === today;

    var head = '<div class="world-head">' +
      '<div class="wt">' + (d.getMonth() + 1) + '月' + d.getDate() + '日 · ' + (isToday ? '世界上的今天' : '世界上的这一天') + '</div>' +
      '<input class="world-date" type="date" id="world-date" value="' + date + '" aria-label="选择日期">' +
      '</div>' +
      (isToday ? '' : '<div style="margin:-10px 0 16px"><button class="pill accent" data-act="world-today">回到今天</button></div>');

    function mineOn(ds) {
      var dd = Store.parseDate(ds);
      return App.state.entries.filter(function (e) {
        var p = String(e.date || '').split('-');
        return Number(p[1]) === dd.getMonth() + 1 && Number(p[2]) === dd.getDate() && e.date !== ds;
      });
    }

    if (!list.length) {
      var mine0 = mineOn(date);
      var near0 = nearbyWorld(d, 8);
      return head + '<div class="empty" style="margin-top:6px"><div class="emoji">🌍</div>' +
        '<div class="t">这一天还没有收录历史事件</div>' +
        '<div class="s">' + (mine0.length ? '不过你在这天写过 ' + mine0.length + ' 条记录' : '可以换一天看看，或先记录自己的今天') + '</div></div>' +
        (mine0.length ? '<div class="timeline" style="padding-top:6px">' + timelineHtml(mine0) + '</div>' : '') +
        nearBlock(near0);
    }

    var rows = '';
    var lastCentury = null;
    list.forEach(function (item, i) {
      var c = World.centuryOf(item.year);
      var showC = c !== lastCentury;
      lastCentury = c;
      var years = item.year < 0 ? '前' + Math.abs(item.year) : String(item.year);
      var yrs = item.year < 0 ? '公元前' + Math.abs(item.year) + '年' : '公元' + item.year + '年';
      var ago = item.year < 0 ? Math.abs(item.year) + ' 多年' : (d.getFullYear() - item.year);
      rows += '<div class="world-row' + (i === 0 ? ' first' : '') + '">' +
        '<div class="c">' + (showC ? c : '') + '</div>' +
        '<div class="railx"><span class="dot' + (i % 2 ? ' alt' : '') + '"></span><span class="vline"></span></div>' +
        '<div class="body">' +
          '<div class="y">' + years + '</div>' +
          '<div class="t">' + esc(item.title) + '</div>' +
          '<div class="m">发生于' + yrs + (item.year > 0 ? (d.getMonth() + 1) + '月' + d.getDate() + '日' : '') + '</div>' +
          '<div class="ago">距今约 ' + ago + ' 年</div>' +
        '</div></div>';
    });

    var mine = mineOn(date).sort(function (a, b) { return (a.date || '') < (b.date || '') ? 1 : -1; });
    var extra = mine.length
      ? '<div class="section-mini">你也在这一天写过</div>' + timelineHtml(mine)
      : '';

    var near = list.length < 4 ? nearbyWorld(d, 8) : [];

    return head + '<div class="world-list">' + rows + '</div>' + extra + nearBlock(near);
  }

  function nearBlock(near) {
    if (!near.length) return '';
    var rows = near.map(function (n) {
      var dd = Store.parseDate(n.date);
      var years = n.item.year < 0 ? '前' + Math.abs(n.item.year) : String(n.item.year);
      return '<div class="near-row">' +
        '<span class="nd">' + (dd.getMonth() + 1) + '月' + dd.getDate() + '日</span>' +
        '<span class="ny">' + years + '</span>' +
        '<span class="nt">' + esc(n.item.title) + '</span></div>';
    }).join('');
    return '<div class="section-mini">这几天也发生过</div><div class="near-list">' + rows + '</div>';
  }

  function annMini() {
    var list = App.state.anniversaries;
    if (!list.length) {
      return '<div class="empty"><div class="emoji">💝</div><div class="t">还没有纪念日</div>' +
        '<div class="s">把重要的日子放进来，它会帮你记着</div>' +
        '<button class="btn primary" data-act="new-ann">添加纪念日</button></div>';
    }
    return '<div class="ann-list" style="padding:8px 0 0">' + list.map(annCard).join('') + '</div>';
  }

  function appTitle() {
    return (App.state.settings && App.state.settings.appTitle) || '人生时间线';
  }

  App.screens.home = function () {
    var head =
      '<header class="topbar">' +
        '<div class="slot left"><button class="icon-btn" data-act="open-drawer" aria-label="菜单">' + icon('menu') + '</button></div>' +
        '<div class="title"><svg class="icon mark" aria-hidden="true"><use href="#i-heart"></use></svg>' + esc(appTitle()) + '</div>' +
        '<div class="slot"><button class="icon-btn plain" data-act="focus-search" aria-label="搜索">' + icon('search') + '</button></div>' +
      '</header>' +
      '<div class="home-head">' +
        (App.tab === 'world' ? '' : '<label class="searchbar">' + icon('search', 'sm') +
          '<input id="q" type="search" placeholder="搜索全部事件和日记" value="' + esc(App.query) + '" autocomplete="off">' +
        '</label>') +
        '<div class="tabs' + (App.tab === 'world' ? ' tight' : '') + '">' + TABS.map(function (t) {
          return '<button class="tab' + (App.tab === t.k ? ' active' : '') + '" data-act="tab" data-tab="' + t.k + '">' + t.label + '</button>';
        }).join('') + '</div>' +
      '</div>';

    var body;
    if (App.tab === 'world') {
      body = '<div class="timeline">' + worldView() + '</div>';
    } else {
      body = '<div class="timeline">' + (App.query || App.tab !== 'all' ? '' : memoryBanner()) +
        timelineHtml(filteredEntries()) + '</div>';
    }

    return '<div class="screen">' + head + body +
      '<button class="fab" data-act="new" aria-label="写日记">' + icon('plus') + '</button></div>';
  };

  /* ---------------- 日历 ---------------- */
  function calState() {
    if (!App.cal) {
      var d = new Date();
      App.cal = { y: d.getFullYear(), m: d.getMonth(), sel: Store.dateStr(d) };
    }
    return App.cal;
  }

  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  function annCard(a) {
    var today = Store.dateStr();
    var out;
    if (a.repeat) {
      var base = Store.parseDate(a.date);
      var now = Store.parseDate(today);
      var next = new Date(now.getFullYear(), base.getMonth(), base.getDate(), 12);
      if (next < now) next = new Date(now.getFullYear() + 1, base.getMonth(), base.getDate(), 12);
      var diff = Math.round((next - now) / 86400000);
      out = { num: diff === 0 ? '今天' : diff, label: diff === 0 ? '就是今天' : '还有 ' + diff + ' 天' };
    } else {
      var since = Store.dayDiff(a.date);
      out = { num: Math.abs(since), label: since >= 0 ? '已经 ' + since + ' 天' : '还有 ' + Math.abs(since) + ' 天' };
    }
    return '<div class="ann-card tapable" data-act="edit-ann" data-id="' + esc(a.id) + '">' +
      '<div class="em">' + esc(a.emoji || '💫') + '</div>' +
      '<div><div class="t">' + esc(a.title) + '</div><div class="d">' +
        esc(U.cnDate(a.date)) + (a.repeat ? ' · 每年' : '') + '</div></div>' +
      '<div class="num"><b>' + esc(String(out.num)) + '</b><span>' + esc(out.label) + '</span></div></div>';
  }

  function monthGrid(cs) {
    var first = new Date(cs.y, cs.m, 1);
    var startOffset = (first.getDay() + 6) % 7;
    var start = new Date(cs.y, cs.m, 1 - startOffset);
    var byDate = distinctDates();
    var today = Store.dateStr();
    var cells = [];
    for (var i = 0; i < 42; i++) {
      var d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
      var ds = Store.dateStr(d);
      var other = d.getMonth() !== cs.m;
      var has = byDate[ds] || [];
      var dots = '';
      if (has.length) {
        dots = '<span class="dot' + (has.some(function (e) { return e.type === 'event'; }) ? ' event' : '') + '"></span>';
      }
      cells.push('<button class="cal-cell' + (other ? ' other' : '') + (ds === cs.sel ? ' sel' : '') +
        (ds === today ? ' today' : '') + '" data-act="cal-day" data-date="' + ds + '">' +
        d.getDate() + dots + '</button>');
    }
    // trim trailing empty week if not in month
    return cells.join('');
  }

  App.screens.calendar = function () {
    var cs = calState();
    var byDate = distinctDates();
    var dayEntries = byDate[cs.sel] || [];
    var selDate = Store.parseDate(cs.sel);
    var panelHead = '<div class="day-panel-head">' +
      '<div><div class="d">' + (selDate.getMonth() + 1) + '月' + selDate.getDate() + '日' +
        '<span class="w">' + U.weekday(cs.sel) + '</span></div>' +
        '<div class="s">' + dayEntries.length + ' 条记录</div></div>' +
      '<button class="add" data-act="day-add" data-date="' + cs.sel + '">' + icon('plus', 'sm') + '记一件小事</button>' +
      '</div>';

    var panelBody;
    if (dayEntries.length) {
      panelBody = dayEntries.map(function (e) {
        return entryCard(e);
      }).join('');
    } else {
      panelBody = '<div class="empty" style="margin:16px 0 0;padding:30px 20px">' +
        '<div class="t" style="margin-top:0">这天还没有记录</div>' +
        '<div class="s">从一件小事开始吧</div></div>';
    }

    return '<div class="screen">' +
      '<header class="topbar">' +
        '<div class="slot left"><button class="icon-btn plain" data-act="back" aria-label="返回">' + icon('back') + '</button></div>' +
        '<div class="title">记事日历</div>' +
        '<div class="slot"><button class="pill" data-act="cal-today">今天</button></div>' +
      '</header>' +
      '<div class="cal-wrap">' +
        '<div class="month-head"><div class="m">' + cs.y + '年' + (cs.m + 1) + '月</div>' +
          '<div class="nav"><button class="icon-btn" data-act="cal-prev" aria-label="上个月">' + icon('back', 'sm') + '</button>' +
          '<button class="icon-btn" data-act="cal-next" aria-label="下个月" style="transform:rotate(180deg)">' + icon('back', 'sm') + '</button></div></div>' +
        '<div class="weekdays">' + U.WEEK.slice(1).concat(U.WEEK[0]).map(function (w) { return '<span>' + w + '</span>'; }).join('') + '</div>' +
        '<div class="cal-grid">' + monthGrid(cs) + '</div>' +
        '<div class="day-panel">' + panelHead + panelBody + '</div>' +
      '</div>' +
      '<button class="fab" data-act="day-add" data-date="' + cs.sel + '" aria-label="写日记">' + icon('plus') + '</button>' +
      '</div>';
  };

  /* ---------------- 详情 ---------------- */
  App.screens.entry = function (params) {
    if (params.id === 'latest') {
      var first = entriesSorted()[0];
      if (first) params.id = first.id;
    }
    var e = getEntry(params.id);
    if (!e) return '<div class="screen"><header class="topbar"><div class="slot left"><button class="icon-btn plain" data-act="back">' + icon('back') + '</button></div><div class="title">日记详情</div><div class="slot"></div></header><div class="empty"><div class="emoji">🌫️</div><div class="t">这条记录不见了</div></div></div>';

    var d = Store.parseDate(e.date);
    var photos = (e.photos || []).map(function (p, i) {
      return '<img src="' + esc(p) + '" alt="" data-act="view-photo" data-src="' + esc(p) + '">';
    }).join('');
    var tags = (e.tags || []).map(function (t) { return '<span class="chip">' + esc(t) + '</span>'; }).join('');
    var linked = e.linkedEventId ? getEntry(e.linkedEventId) : null;
    var linkBlock = linked
      ? '<div class="link-row tapable" data-act="open-entry" data-id="' + esc(linked.id) + '">' + icon('link') +
          '<div><div class="l">关联事件</div><div class="v">' + esc(linked.title) + '</div></div>' +
          '<span class="chev">' + icon('chev', 'sm') + '</span></div>'
      : '<div class="link-row tapable" data-act="link-event" data-id="' + esc(e.id) + '">' + icon('link') +
          '<div><div class="l">关联事件</div><div class="v" style="color:var(--ink-3);font-weight:400">添加关联事件</div></div>' +
          '<span class="chev">' + icon('chev', 'sm') + '</span></div>';

    var letter = e.letter
      ? '<div class="letter-card"><div class="h">' + icon('mail', 'sm') + '写给后来的自己</div>' +
        '<div class="c">' + esc(e.letter) + '</div><div class="hint">写于 ' + esc(U.relTime(e.createdAt) || '') + '</div></div>'
      : '';

    return '<div class="screen">' +
      '<header class="topbar">' +
        '<div class="slot left"><button class="icon-btn plain" data-act="back" aria-label="返回">' + icon('back') + '</button></div>' +
        '<div class="title">日记详情</div>' +
        '<div class="slot"><button class="text-btn strong" data-act="edit-entry" data-id="' + esc(e.id) + '">编辑</button>' +
        '<button class="icon-btn plain" data-act="more-entry" data-id="' + esc(e.id) + '" aria-label="更多">' + icon('more') + '</button></div>' +
      '</header>' +
      '<div class="detail-head"><div class="detail-date">' +
        '<div class="big-day">' + d.getDate() + '<span class="day-suffix">日</span></div>' +
        '<div class="col"><div class="year">' + d.getFullYear() + ' · ' + (d.getMonth() + 1) + '月</div>' +
        '<div class="mood">' + esc(e.emoji || moodEmoji(e.mood)) + ' ' + esc(e.time || '') + '</div></div>' +
      '</div></div>' +
      '<div class="detail-body">' +
        '<h1 class="detail-title">' + esc(e.title || '无标题') + '</h1>' +
        '<div class="detail-meta"><span>' + U.weekday(e.date) + '</span>' +
          (e.date ? '<span>·</span><span>' + esc(U.daysText(e.date)) + '</span>' : '') +
          (e.notebook ? '<span>·</span><span>' + esc(e.notebook) + '</span>' : '') +
          (e.type === 'event' ? '<span>·</span><span>事件</span>' : '') +
        '</div>' +
        (e.content ? '<div class="detail-content">' + esc(e.content) + '</div>' : '') +
        (photos ? '<div class="detail-photos">' + photos + '</div>' : '') +
        (tags ? '<div class="detail-tags">' + tags + '</div>' : '') +
        linkBlock +
        letter +
        '<div class="detail-foot">创建于 ' + esc(e.createdAt ? new Date(e.createdAt).toLocaleString('zh-CN', { hour12: false }) : '—') +
          (e.updatedAt && e.updatedAt !== e.createdAt ? '<br>最后编辑 ' + esc(new Date(e.updatedAt).toLocaleString('zh-CN', { hour12: false })) : '') +
        '</div>' +
      '</div>' +
      '</div>';
  };

  /* ---------------- 抽屉 ---------------- */
  function drawerHtml() {
    var p = App.state.profile || {};
    var diaries = App.state.entries.filter(function (e) { return e.type !== 'event'; }).length;
    var eventsCount = App.state.entries.filter(function (e) { return e.type === 'event'; }).length;
    return '<div class="drawer">' +
      '<div class="backdrop" data-act="close-drawer"></div>' +
      '<div class="panel">' +
        '<div class="profile-card tapable" data-act="edit-profile">' +
          (p.avatarImage
            ? '<div class="av img"><img src="' + esc(p.avatarImage) + '" alt=""></div>'
            : '<div class="av">' + esc(p.avatar || '🌿') + '</div>') +
          '<div class="pf"><div class="name">' + esc(p.nickname || '我') + '</div>' +
          '<div class="sub">已记录 ' + countDays() + ' 个日子</div>' +
          '<div class="sub link">查看个人资料</div></div>' +
          '<span class="more">' + icon('chev', 'sm') + '</span>' +
        '</div>' +
        '<div class="stat-line"><span><b>' + diaries + '</b> 篇日记</span><span class="sep">·</span>' +
          '<span><b>' + eventsCount + '</b> 个事件</span><span class="sep">·</span>' +
          '<span><b>' + App.state.anniversaries.length + '</b> 个纪念日</span></div>' +

        '<div class="menu-sep"><span>生活值得被记录</span></div>' +
        '<div class="menu-group">' +
          '<button class="menu-item" data-act="nav" data-to="/calendar"><span class="ic">' + icon('calendar') + '</span>' +
            '<span class="tx"><span class="t">日历</span><span class="s">按日期翻看</span></span>' +
            '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
          '<button class="menu-item" data-act="nav" data-to="/anniversary"><span class="ic">' + icon('heart') + '</span>' +
            '<span class="tx"><span class="t">纪念日</span><span class="s">珍藏重要日子</span></span>' +
            '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
          '<button class="menu-item" data-act="nav" data-to="/world"><span class="ic">' + icon('world') + '</span>' +
            '<span class="tx"><span class="t">世界上的今天</span><span class="s">看看历史上的这一天</span></span>' +
            '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
        '</div>' +
        '<div class="menu-sep"><span>整理与设置</span></div>' +
        '<div class="menu-group">' +
          '<button class="menu-item" data-act="nav" data-to="/manage"><span class="ic">' + icon('grid') + '</span>' +
            '<span class="tx"><span class="t">整理</span><span class="s">管理事件本与标签</span></span>' +
            '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
          '<button class="menu-item" data-act="nav" data-to="/data"><span class="ic">' + icon('box') + '</span>' +
            '<span class="tx"><span class="t">数据管理</span><span class="s">备份与恢复</span></span>' +
            '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
          '<button class="menu-item" data-act="nav" data-to="/settings"><span class="ic">' + icon('gear') + '</span>' +
            '<span class="tx"><span class="t">高级设置</span><span class="s">更多个性选项</span></span>' +
            '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
        '</div>' +
        '<div style="margin-top:26px;padding:0 8px;font-size:11.5px;color:var(--ink-3)">' + esc(appTitle()) + ' · 本地存储，不上传任何内容</div>' +
      '</div></div>';
  }

  function openDrawer() {
    var host = document.createElement('div');
    host.id = 'drawer-host';
    host.innerHTML = drawerHtml();
    document.body.appendChild(host);
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer() {
    var host = U.el('drawer-host');
    if (host) { host.remove(); document.body.style.overflow = ''; }
  }

  /* ---------------- 动作 ---------------- */
  App.act = function (name, fn) { App.actions[name] = fn; };

  App.act('open-drawer', openDrawer);
  App.act('close-drawer', closeDrawer);
  App.act('nav', function (el) { closeDrawer(); navigate(el.dataset.to); });
  App.act('back', function () { back(); });
  App.act('tab', function (el) {
    App.tab = el.dataset.tab;
    App.query = '';
    render();
  });
  App.act('focus-search', function () {
    var q = U.el('q');
    if (q) { q.focus(); q.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  });
  App.act('open-entry', function (el) { navigate('/entry/' + el.dataset.id); });
  App.act('edit-entry', function (el) { navigate('/edit/' + el.dataset.id); });
  App.act('edit-profile', function () { closeDrawer(); navigate('/profile'); });
  App.act('new', function () { navigate('/new'); });
  App.act('open-memories', function () { navigate('/memories'); });
  App.act('world-today', function () { App.worldDate = ''; render(); });
  App.screens.world = function () {
    App.tab = 'world';
    return App.screens.home();
  };
  App.act('view-photo', function (el) { U.viewPhoto(el.dataset.src); });
  App.act('close-sheet', function () { U.closeSheet(); });

  App.act('cal-day', function (el) {
    var cs = calState();
    cs.sel = el.dataset.date;
    render();
  });
  App.act('cal-prev', function () {
    var cs = calState();
    cs.m--; if (cs.m < 0) { cs.m = 11; cs.y--; }
    cs.sel = cs.y + '-' + pad2(cs.m + 1) + '-01';
    render();
  });
  App.act('cal-next', function () {
    var cs = calState();
    cs.m++; if (cs.m > 11) { cs.m = 0; cs.y++; }
    cs.sel = cs.y + '-' + pad2(cs.m + 1) + '-01';
    render();
  });
  App.act('cal-today', function () {
    var d = new Date();
    App.cal = { y: d.getFullYear(), m: d.getMonth(), sel: Store.dateStr(d) };
    render();
  });
  App.act('day-add', function (el) {
    navigate('/new?date=' + el.dataset.date);
  });

  App.act('more-entry', function (el) {
    var e = getEntry(el.dataset.id);
    if (!e) return;
    U.openSheet('<div class="sheet-head"><div class="t">' + esc(e.type === 'event' ? '事件' : '日记') + '</div>' +
      '<button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body">' +
      '<button class="sheet-row" data-act="edit-entry" data-id="' + esc(e.id) + '">' + icon('edit') + '<span class="t">编辑</span></button>' +
      '<button class="sheet-row" data-act="share-entry" data-id="' + esc(e.id) + '">' + icon('share') + '<span class="t">分享</span></button>' +
      '<button class="sheet-row danger" data-act="delete-entry" data-id="' + esc(e.id) + '">' + icon('trash') + '<span class="t">删除</span></button>' +
      '</div>');
  });

  App.act('delete-entry', function (el) {
    var id = el.dataset.id;
    U.closeSheet();
    U.confirmSheet('删除这条记录？', '删除后无法恢复，记得先备份。', '删除', function () {
      App.state.entries = App.state.entries.filter(function (x) { return x.id !== id; });
      save();
      U.toast('已删除');
      navigate('/');
    }, true);
  });

  App.act('share-entry', function (el) {
    var e = getEntry(el.dataset.id);
    if (!e) return;
    U.closeSheet();
    var text = (e.title ? e.title + '\n' : '') + (e.content || '') +
      '\n—— ' + e.date + ' ' + (e.time || '') + ' · 人生时间线';
    if (navigator.share) {
      navigator.share({ title: e.title || '人生时间线', text: text }).catch(function () { });
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(function () { U.toast('已复制到剪贴板'); },
        function () { U.toast('复制失败'); });
    } else {
      U.toast('当前环境不支持分享');
    }
  });

  /* ---------------- 路由监听 ---------------- */
  function boot() {
    if (String(location.search).indexOf('noanim=1') >= 0) {
      document.documentElement.classList.add('no-anim');
    }
    if (String(location.search).indexOf('debug=1') >= 0) {
      var banner = function (msg) {
        var box = document.getElementById('err-banner');
        if (!box) {
          box = document.createElement('div');
          box.id = 'err-banner';
          box.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:9999;background:#c0392b;color:#fff;font:12px/1.5 monospace;padding:8px 10px;white-space:pre-wrap;max-height:40vh;overflow:auto';
          document.body.appendChild(box);
        }
        box.textContent += msg + '\n';
      };
      window.addEventListener('error', function (ev) {
        banner('ERR: ' + (ev.message || ev.error) + ' @' + (ev.filename || '') + ':' + (ev.lineno || ''));
      });
      window.addEventListener('unhandledrejection', function (ev) {
        banner('REJ: ' + ((ev.reason && (ev.reason.message || ev.reason)) || 'unknown'));
      });
    }

    Store.load().then(function (st) {
      App.state = st;
      applySettings();
      App.cal = null;
      render();
      if (String(location.search).indexOf('drawer=1') >= 0) {
        setTimeout(function () { openDrawer(); }, 300);
      }
      try { syncReminder(); } catch (e) { }
      setTimeout(function () {
        try { App.route = parseHash().name; maybeShowMemories(); } catch (e) { }
      }, 700);
    }).catch(function (err) {
      U.el('app').innerHTML = '<div class="empty"><div class="emoji">😵</div><div class="t">数据加载失败</div>' +
        '<div class="s">' + esc(err && err.message) + '</div></div>';
    });

    window.addEventListener('hashchange', function () {
      closeDrawer();
      render();
    });

    document.addEventListener('input', function (ev) {
      var t = ev.target;
      if (t && t.id === 'q') {
        App.query = t.value;
        var tl = document.querySelector('.timeline');
        if (tl) tl.innerHTML = timelineHtml(filteredEntries());
      }
    });

    document.addEventListener('click', function (ev) {
      var el = ev.target.closest ? ev.target.closest('[data-act]') : null;
      if (!el) return;
      var act = el.dataset.act;
      var fn = App.actions[act];
      if (!fn) return;
      ev.preventDefault();
      ev.stopPropagation();
      fn(el, ev);
    });

    var overlay = U.el('overlay');
    if (overlay) overlay.addEventListener('click', function () { U.closeSheet(); });

    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') { U.closeSheet(); closeDrawer(); }
    });
  }

  App.save = save;
  App.navigate = navigate;
  App.back = back;
  App.render = render;  App.getEntry = getEntry;
  App.moodEmoji = moodEmoji;
  App.entriesSorted = entriesSorted;
  App.applySettings = applySettings;
  App.ACCENTS = ACCENTS;
  App.countDays = countDays;
  App.memoriesFor = memoriesFor;
  App.syncReminder = syncReminder;
  App.requestNotifyPermission = requestNotifyPermission;
  App.events = events;
  App.annCard = annCard;
  App.openDrawer = openDrawer;
  App.closeDrawer = closeDrawer;

  /* 安卓物理返回键：优先关闭弹层 / 抽屉 */
  global.__handleBack = function () {
    if (U.isSheetOpen()) { U.closeSheet(); return true; }
    if (U.el('drawer-host')) { closeDrawer(); return true; }
    return false;
  };

  global.App = App;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(window);
