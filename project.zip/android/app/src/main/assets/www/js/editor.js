﻿/* 写日记 / 纪念日 / 设置 / 数据 / 整理 */
(function (global) {
  'use strict';

  var App = global.App;
  var U = UI;
  var icon = U.icon;
  var esc = U.esc;

  var MOODS = ['😄', '🙂', '😌', '😔', '😤'];
  var EMOJIS = [
    '🌱', '🌸', '🌻', '🍀', '🌙', '☀️', '⭐️', '🌈', '🌊', '⛰️',
    '🌧️', '❄️', '🔥', '🌿', '🍂', '🪴',
    '🐱', '🐶', '🐰', '🐼', '🦊', '🐟', '🦋', '🐣',
    '🍜', '🍰', '🍎', '☕️', '🍵', '🍻', '🍦', '🍙',
    '🏡', '🏫', '🏔️', '🏖️', '🚲', '🚗', '✈️', '🚄',
    '🎈', '🎂', '🎁', '🎉', '🎬', '🎧', '🎮', '📚',
    '📷', '💻', '📱', '✏️', '📝', '💌', '🎨', '🧸',
    '💐', '🌹', '💊', '🏃', '🧘', '🌙', '💤', '🕯️',
    '📌', '📎', '🗓️', '🔥', '💡', '✅', '❤️', '💫'
  ];

  function blurPx(s) {
    var px = s.bgBlurPx;
    if (px === undefined || px === null || px === '') {
      var legacy = (s.bgBlur === undefined || s.bgBlur === '') ? null : Number(s.bgBlur);
      px = legacy === null ? 6 : [0, 2, 6, 12][legacy];
      if (px === undefined) px = 6;
    }
    return Math.max(0, Math.min(20, Number(px) || 0));
  }

  function today() { return Store.dateStr(new Date()); }
  function nowTime() { return Store.timeStr(new Date()); }

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  function readQueryDate() {
    var q = String(location.hash || '').split('?')[1] || '';
    var m = /(?:^|&)date=([0-9]{4}-[0-9]{2}-[0-9]{2})/.exec(q);
    return m ? m[1] : '';
  }

  function newDraft(presetDate) {
    return {
      id: '',
      type: 'diary',
      date: presetDate || readQueryDate() || today(),
      time: nowTime(),
      title: '',
      content: '',
      mood: 1,
      emoji: '',
      photos: [],
      tags: [],
      notebook: (App.state.notebooks && App.state.notebooks[0]) || '小本子',
      linkedEventId: '',
      letter: '',
      createdAt: '',
      updatedAt: '',
      __new: true
    };
  }

  function ensureDraft(params) {
    var id = params && params.id;
    if (id && id !== 'new') {
      if (App.draft && App.draft.id === id) return App.draft;
      var e = App.getEntry(id);
      if (e) { App.draft = clone(e); return App.draft; }
    }
    if (App.draft && App.draft.__new) return App.draft;
    App.draft = newDraft();
    return App.draft;
  }

  function isDirty(d) {
    return !!(d.title || d.content || (d.photos && d.photos.length) || d.letter);
  }

  /* ---------------- 编辑器 ---------------- */
  function renderEditor(params) {
    var d = ensureDraft(params);
    var photoHtml = (d.photos || []).map(function (p, i) {
      return '<div class="photo-thumb"><img src="' + esc(p) + '" alt="" data-act="view-photo" data-src="' + esc(p) + '">' +
        '<button class="rm" data-act="rm-photo" data-idx="' + i + '" aria-label="移除">' + icon('close', 'sm') + '</button></div>';
    }).join('');

    var tags = (d.tags || []).map(function (t) {
      return '<span class="chip on">' + esc(t) + '</span>';
    }).join('');

    return '<div class="screen editor">' +
      '<header class="topbar">' +
        '<div class="slot left"><button class="icon-btn plain" data-act="cancel-edit" aria-label="关闭">' + icon('close') + '</button></div>' +
        '<div class="title">写' + (d.type === 'event' ? '事件' : '日记') + '</div>' +
        '<div class="slot"><button class="text-btn strong" data-act="save-entry">完成</button></div>' +
      '</header>' +

      '<div class="mood-row" id="mood-row">' + MOODS.map(function (m, i) {
        return '<button class="mood' + (Number(d.mood) === i ? ' on' : '') + '" data-act="pick-mood" data-mood="' + i + '">' + m + '</button>';
      }).join('') + '</div>' +

      '<div class="editor-meta">' +
        '<span class="edit-date">' + icon('calendar', 'sm') + '</span>' +
        '<input type="date" data-field="date" value="' + esc(d.date) + '" aria-label="日期">' +
        '<input type="time" data-field="time" value="' + esc(d.time) + '" aria-label="时间">' +
        '<button class="pill" data-act="pick-emoji" style="margin-left:auto">' +
          '<span style="font-size:16px">' + esc(d.emoji || MOODS[Number(d.mood) || 0]) + '</span> 表情</button>' +
      '</div>' +

      '<div class="editor-body">' +
        '<input class="title-input" type="text" data-field="title" placeholder="给今天一个标题（可选）" value="' + esc(d.title) + '">' +
        '<textarea class="content-input" data-field="content" id="content" placeholder="写下此刻……">' + esc(d.content) + '</textarea>' +
      '</div>' +

      '<div class="editor-photos" id="photo-strip">' + photoHtml + '</div>' +

      '<div class="editor-letter">' +
        '<button class="letter-toggle" data-act="toggle-letter">' + icon('mail', 'sm') + '写给后来的自己' +
          '<span style="color:var(--ink-3);font-size:12px">（可选）</span></button>' +
        '<textarea class="letter-input" data-field="letter" id="letter-input" placeholder="若干年后的你，会看到这段话……"' +
          (d.letter ? '' : ' hidden') + '>' + esc(d.letter) + '</textarea>' +
      '</div>' +

      '<div class="editor-bar"><div class="inner">' +
        '<button class="tool" data-act="pick-notebook">' + icon('book', 'sm') + esc(d.notebook || '小本子') + '</button>' +
        '<button class="tool' + (tags ? ' on' : '') + '" data-act="pick-tags">' + icon('tag', 'sm') + '标签</button>' +
        '<button class="tool' + (d.linkedEventId ? ' on' : '') + '" data-act="link-event">' + icon('link', 'sm') + '事件</button>' +
        '<button class="tool spacer" data-act="add-photo" aria-label="添加照片">' + icon('camera') + '</button>' +
      '</div></div>' +

      '<input type="file" id="photo-input" accept="image/*" multiple hidden>' +
      '<input type="file" id="camera-input" accept="image/*" capture="environment" hidden>' +
      '</div>';
  }

  App.screens.editor = renderEditor;
  App.screens.new = renderEditor;
  App.screens.edit = renderEditor;

  /* ---------------- 编辑器动作 ---------------- */
  App.act('cancel-edit', function () {
    App.linkTarget = '';
    var d = App.draft;
    var goBack = function () { App.draft = null; App.back(); };
    if (d && isDirty(d)) {
      U.confirmSheet('放弃这次编辑？', '已经写下的内容不会保存。', '放弃', goBack, true);
    } else {
      goBack();
    }
  });

  App.act('pick-mood', function (el) {
    var d = App.draft;
    d.mood = Number(el.dataset.mood);
    var row = U.el('mood-row');
    if (row) {
      Array.prototype.forEach.call(row.children, function (b) {
        b.classList.toggle('on', Number(b.dataset.mood) === d.mood);
      });
    }
    var pill = document.querySelector('[data-act="pick-emoji"] span');
    if (pill && !d.emoji) pill.textContent = MOODS[d.mood];
  });

  App.act('pick-emoji', function () {
    var d = App.draft;
    U.openSheet('<div class="sheet-head"><div class="t">选一个表情</div>' +
      '<button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body"><div style="display:grid;grid-template-columns:repeat(6,1fr);gap:8px">' +
      EMOJIS.map(function (e) {
        return '<button style="font-size:26px;height:52px;border-radius:14px;background:rgba(255,255,255,.7)" data-act="set-emoji" data-emoji="' + e + '">' + e + '</button>';
      }).join('') + '</div></div>');
  });

  App.act('set-emoji', function (el) {
    App.draft.emoji = el.dataset.emoji;
    U.closeSheet();
    App.render();
  });

  App.act('toggle-letter', function () {
    var t = U.el('letter-input');
    if (!t) return;
    t.hidden = !t.hidden;
    if (!t.hidden) t.focus();
  });

  App.act('pick-notebook', function () {
    var list = App.state.notebooks || [];
    U.openSheet('<div class="sheet-head"><div class="t">选择本子</div>' +
      '<button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body">' + list.map(function (n) {
        var on = App.draft.notebook === n;
        return '<button class="sheet-row" data-act="set-notebook" data-name="' + esc(n) + '">' +
          '<span class="t">' + esc(n) + '</span>' + (on ? icon('check', 'sm') : '') + '</button>';
      }).join('') + '<div style="display:flex;gap:8px;padding:10px 8px">' +
      '<input id="new-notebook" placeholder="新本子名称" style="flex:1;height:40px;padding:0 12px;border-radius:12px;background:rgba(255,255,255,.8)">' +
      '<button class="btn" data-act="add-notebook-inline">添加</button></div></div>');
  });

  App.act('set-notebook', function (el) {
    App.draft.notebook = el.dataset.name;
    U.closeSheet();
    App.render();
  });

  App.act('add-notebook-inline', function () {
    var v = (U.el('new-notebook') || {}).value || '';
    v = v.trim();
    if (!v) return;
    if (App.state.notebooks.indexOf(v) < 0) App.state.notebooks.push(v);
    App.draft.notebook = v;
    App.save();
    U.closeSheet();
    App.render();
  });

  App.act('pick-tags', function () {
    var all = App.state.tags || [];
    var html = '<div class="sheet-head"><div class="t">标签</div>' +
      '<button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body"><div style="display:flex;flex-wrap:wrap;gap:8px;padding:4px 0 14px">' +
      all.map(function (t) {
        var on = (App.draft.tags || []).indexOf(t) >= 0;
        return '<button class="chip' + (on ? ' on' : '') + '" data-act="toggle-tag" data-name="' + esc(t) + '">' + esc(t) + '</button>';
      }).join('') + '</div>' +
      '<div style="display:flex;gap:8px"><input id="new-tag" placeholder="新标签" style="flex:1;height:40px;padding:0 12px;border-radius:12px;background:rgba(255,255,255,.8)">' +
      '<button class="btn" data-act="add-tag-inline">添加</button></div></div>';
    U.openSheet(html);
  });

  App.act('toggle-tag', function (el) {
    var name = el.dataset.name;
    var tags = App.draft.tags || (App.draft.tags = []);
    var i = tags.indexOf(name);
    if (i >= 0) tags.splice(i, 1); else tags.push(name);
    el.classList.toggle('on');
    syncToolbar();
  });

  function syncToolbar() {
    var d = App.draft;
    var tools = document.querySelectorAll('.editor-bar .tool');
    if (tools.length >= 3) {
      tools[1].classList.toggle('on', !!(d.tags && d.tags.length));
      tools[2].classList.toggle('on', !!d.linkedEventId);
    }
  }

  App.act('add-tag-inline', function () {
    var v = ((U.el('new-tag') || {}).value || '').trim();
    if (!v) return;
    if (App.state.tags.indexOf(v) < 0) App.state.tags.push(v);
    if ((App.draft.tags || []).indexOf(v) < 0) App.draft.tags.push(v);
    App.save();
    U.closeSheet();
    App.render();
  });

  /* 关联事件 */
  App.act('link-event', function (el) {
    App.linkTarget = (!App.draft && el && el.dataset) ? (el.dataset.id || '') : '';
    var list = App.events();
    var html = '<div class="sheet-head"><div class="t">选择事件</div>' +
      '<button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body">' +
      '<div class="searchbar" style="height:40px;margin-bottom:10px">' + icon('search', 'sm') +
      '<input id="ev-q" placeholder="搜索事件名称、备注或日期"></div>' +
      '<div id="ev-list">' + eventRows(list) + '</div>' +
      '<button class="btn block" style="margin-top:14px" data-act="new-event">＋ 新建事件</button></div>';
    U.openSheet(html);
    var q = U.el('ev-q');
    if (q) q.addEventListener('input', function () {
      var v = q.value.trim().toLowerCase();
      var filtered = list.filter(function (e) {
        return ((e.title || '') + (e.content || '') + e.date).toLowerCase().indexOf(v) >= 0;
      });
      U.el('ev-list').innerHTML = eventRows(filtered);
    });
  });

  function eventRows(list) {
    if (!list.length) return '<div class="empty" style="margin:10px 0"><div class="emoji">🗓️</div><div class="t">还没有事件</div><div class="s">请先创建一些事件</div></div>';
    return list.map(function (e) {
      return '<button class="sheet-row" data-act="choose-event" data-id="' + esc(e.id) + '">' +
        '<span style="font-size:20px">' + esc(e.emoji || '📌') + '</span>' +
        '<span class="t">' + esc(e.title) + '<div class="s">' + esc(e.date) + '</div></span>' +
        (currentLinkedId() === e.id ? icon('check', 'sm') : '') + '</button>';
    }).join('');
  }

  function currentLinkedId() {
    if (App.linkTarget) {
      var e = App.getEntry(App.linkTarget);
      return e ? e.linkedEventId : '';
    }
    return App.draft ? App.draft.linkedEventId : '';
  }

  App.act('choose-event', function (el) {
    var id = el.dataset.id;
    if (App.linkTarget) {
      var target = App.getEntry(App.linkTarget);
      if (target) {
        target.linkedEventId = target.linkedEventId === id ? '' : id;
        target.updatedAt = new Date().toISOString();
        App.save();
      }
      var linked = target && target.linkedEventId;
      App.linkTarget = '';
      U.closeSheet();
      App.render();
      U.toast(linked ? '已关联事件' : '已取消关联');
      return;
    }
    if (!App.draft) return;
    App.draft.linkedEventId = id;
    U.closeSheet();
    App.render();
  });

  App.act('new-event', function () {
    U.closeSheet();
    App.draft = {
      id: '', type: 'event', date: today(), time: nowTime(),
      title: '', content: '', mood: 1, emoji: '📌', photos: [], tags: [],
      notebook: '小本子', linkedEventId: '', letter: '', createdAt: '', updatedAt: '', __new: true
    };
    App.navigate('/new');
    setTimeout(function () { App.render(); }, 0);
  });

  /* 照片 */
  App.act('add-photo', function () {
    U.openSheet('<div class="sheet-head"><div class="t">添加照片</div>' +
      '<button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body">' +
      '<button class="sheet-row" data-act="shoot-photo">' + icon('camera') + '<span class="t">拍照</span></button>' +
      '<button class="sheet-row" data-act="pick-photo">' + icon('grid') + '<span class="t">从相册选择</span></button>' +
      '</div>');
  });

  App.act('shoot-photo', function () {
    U.closeSheet();
    var input = U.el('camera-input');
    if (input) input.click();
  });

  App.act('pick-photo', function () {
    U.closeSheet();
    var input = U.el('photo-input');
    if (input) input.click();
  });

  App.act('rm-photo', function (el) {
    App.draft.photos.splice(Number(el.dataset.idx), 1);
    renderPhotoStrip();
  });

  function renderPhotoStrip() {
    var strip = U.el('photo-strip');
    if (!strip) return;
    strip.innerHTML = (App.draft.photos || []).map(function (p, i) {
      return '<div class="photo-thumb"><img src="' + esc(p) + '" alt="" data-act="view-photo" data-src="' + esc(p) + '">' +
        '<button class="rm" data-act="rm-photo" data-idx="' + i + '">' + icon('close', 'sm') + '</button></div>';
    }).join('');
  }

  function handleFiles(files) {
    var list = Array.prototype.slice.call(files || []).filter(function (f) {
      return /^image\//.test(f.type);
    });
    if (!list.length) return;
    var pending = list.length, done = 0;
    var lsMode = Store.mode && Store.mode() === 'ls';
    U.toast('正在处理照片…');
    list.forEach(function (f) {
      U.compressImage(f, lsMode ? 1100 : 1600, lsMode ? 0.72 : 0.82).then(function (res) {
        App.draft.photos.push(res.data);
        done++;
        if (done === pending) { renderPhotoStrip(); U.toast('已添加 ' + done + ' 张照片'); }
      }).catch(function () {
        done++;
        U.toast('有照片处理失败');
        if (done === pending) renderPhotoStrip();
      });
    });
  }

  /* 保存 */
  App.act('save-entry', function () {
    var d = App.draft;
    if (!d) return;
    if (!d.title && !d.content && !(d.photos || []).length) {
      U.toast('写点什么再保存吧');
      return;
    }
    var nowIso = new Date().toISOString();
    if (!d.id) {
      d.id = Store.uid(d.type === 'event' ? 'v' : 'e');
      d.createdAt = nowIso;
    }
    d.updatedAt = nowIso;
    if (!d.title) d.title = d.type === 'event' ? '一件事' : '无标题';
    delete d.__new;

    var exists = false;
    App.state.entries = App.state.entries.map(function (x) {
      if (x.id === d.id) { exists = true; return d; }
      return x;
    });
    if (!exists) App.state.entries.push(d);
    App.save();
    if (App.linkTarget) {
      var linkTargetEntry = App.getEntry(App.linkTarget);
      if (linkTargetEntry && d.type === 'event') {
        linkTargetEntry.linkedEventId = d.id;
        App.save();
      }
      App.linkTarget = '';
    }
    U.toast('已保存');
    var id = d.id;
    App.draft = null;
    App.navigate('/entry/' + id, true);
    setTimeout(function () { App.render(); }, 0);
  });

  /* ---------------- 纪念日 ---------------- */
  App.screens.anniversary = function () {
    var list = App.state.anniversaries || [];
    return '<div class="screen">' +
      '<header class="topbar">' +
        '<div class="slot left"><button class="icon-btn plain" data-act="back">' + icon('back') + '</button></div>' +
        '<div class="title">纪念日</div>' +
        '<div class="slot"><button class="icon-btn plain" data-act="new-ann">' + icon('plus') + '</button></div>' +
      '</header>' +
      '<div class="ann-list">' +
        (list.length ? list.map(App.annCard).join('') :
          '<div class="empty"><div class="emoji">💝</div><div class="t">还没有纪念日</div>' +
          '<div class="s">把重要的日子放进来，它会帮你记着</div></div>') +
        '<button class="btn block" style="margin-top:6px" data-act="new-ann">＋ 添加纪念日</button>' +
        '<div class="detail-foot">纪念日按本地日期计算，每年循环的会显示下一次还有多久</div>' +
      '</div></div>';
  };

  App.act('new-ann', function () {
    openAnnSheet(null);
  });

  App.act('edit-ann', function (el) {
    var a = null;
    (App.state.anniversaries || []).forEach(function (x) { if (x.id === el.dataset.id) a = x; });
    openAnnSheet(a);
  });

  function openAnnSheet(a) {
    var editing = !!a;
    var data = a ? clone(a) : { id: '', title: '', date: today(), emoji: '💫', note: '', repeat: true };
    var html = '<div class="sheet-head"><div class="t">' + (editing ? '编辑纪念日' : '添加纪念日') + '</div>' +
      '<button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body">' +
      '<div style="display:flex;gap:10px;align-items:center;margin-bottom:10px">' +
        '<button class="icon-btn" style="font-size:20px;width:44px;height:44px" data-act="ann-emoji">' + esc(data.emoji) + '</button>' +
        '<input id="ann-title" placeholder="纪念什么？" value="' + esc(data.title) + '" style="flex:1;height:44px;padding:0 14px;border-radius:14px;background:rgba(255,255,255,.8)">' +
      '</div>' +
      '<input id="ann-date" type="date" value="' + esc(data.date) + '" style="width:100%;height:44px;padding:0 14px;border-radius:14px;background:rgba(255,255,255,.8)">' +
      '<input id="ann-note" placeholder="备注（可选）" value="' + esc(data.note || '') + '" style="width:100%;height:44px;padding:0 14px;border-radius:14px;background:rgba(255,255,255,.8);margin-top:10px">' +
      '<label style="display:flex;align-items:center;gap:10px;padding:14px 6px;font-size:14px;color:var(--ink-2)">' +
        '<input id="ann-repeat" type="checkbox"' + (data.repeat ? ' checked' : '') + ' style="width:20px;height:20px;accent-color:var(--accent)">每年循环</label>' +
      '<button class="btn primary block" data-act="save-ann" data-id="' + esc(data.id) + '">保存</button>' +
      (editing ? '<button class="btn danger block" style="margin-top:10px" data-act="del-ann" data-id="' + esc(data.id) + '">删除</button>' : '') +
      '</div>';
    U.openSheet(html, {
      onMount: function (root) {
        var btn = root.querySelector('[data-act="ann-emoji"]');
        btn.addEventListener('click', function () {
          var em = prompt('输入一个表情', data.emoji);
          if (em) { data.emoji = em.slice(0, 4); btn.textContent = data.emoji; }
        });
      }
    });
  }

  App.act('save-ann', function (el) {
    var id = el.dataset.id;
    var title = ((U.el('ann-title') || {}).value || '').trim();
    var date = (U.el('ann-date') || {}).value || today();
    var note = ((U.el('ann-note') || {}).value || '').trim();
    var repeat = !!(U.el('ann-repeat') || {}).checked;
    var emojiEl = document.querySelector('[data-act="ann-emoji"]');
    var emoji = emojiEl ? emojiEl.textContent.trim() : '💫';
    if (!title) { U.toast('给它起个名字吧'); return; }
    if (id) {
      App.state.anniversaries = App.state.anniversaries.map(function (x) {
        if (x.id !== id) return x;
        return { id: id, title: title, date: date, note: note, repeat: repeat, emoji: emoji };
      });
    } else {
      App.state.anniversaries.push({ id: Store.uid('a'), title: title, date: date, note: note, repeat: repeat, emoji: emoji });
    }
    App.save();
    U.closeSheet();
    U.toast('已保存');
    App.render();
  });

  App.act('del-ann', function (el) {
    var id = el.dataset.id;
    U.closeSheet();
    U.confirmSheet('删除这个纪念日？', '', '删除', function () {
      App.state.anniversaries = App.state.anniversaries.filter(function (x) { return x.id !== id; });
      App.save();
      App.render();
    }, true);
  });

  /* ---------------- 设置 ---------------- */
  App.screens.settings = function () {
    var s = App.state.settings || {};
    var p = App.state.profile || {};
    return '<div class="screen">' +
      '<header class="topbar">' +
        '<div class="slot left"><button class="icon-btn plain" data-act="back">' + icon('back') + '</button></div>' +
        '<div class="title">高级设置</div>' +
        '<div class="slot"></div>' +
      '</header>' +
      '<div class="list">' +
        '<button class="row" data-act="edit-profile">' +
          '<span class="ic" style="font-size:18px">' + esc(p.avatar || '🌿') + '</span>' +
          '<span class="tx"><span class="t">' + esc(p.nickname || '我') + '</span><span class="s">昵称与头像</span></span>' +
          '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
        '<button class="row" data-act="rename-app">' +
          '<span class="ic">' + icon('edit') + '</span>' +
          '<span class="tx"><span class="t">顶栏名称</span><span class="s">显示在首页顶部</span></span>' +
          '<span class="val">' + esc(s.appTitle || '时光手记') + '</span>' +
          '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
      '</div>' +
      '<div class="section-title">风格</div>' +
      '<div class="theme-grid">' +
        [['warm', '温暖米色'], ['minimal', '极简留白'], ['cream', '奶油米'], ['ink', '墨色山水'], ['mint', '薄荷清晨'], ['ocean', '海盐蓝'], ['sunset', '落日暖橙'], ['sticker', '手账贴纸'], ['dark', '深色夜间'], ['night', '深蓝夜']].map(function (t) {
          var on = (s.theme || 'warm') === t[0];
          return '<button class="theme-card' + (on ? ' on' : '') + '" data-act="set-theme" data-k="' + t[0] + '">' +
            '<span class="tw t-' + t[0] + '"></span><span class="tn">' + t[1] + '</span></button>';
        }).join('') +
      '</div>' +

      ((s.bgImage && (((s.bgVideoIds || []).length) || ((s.bigVideos || []).length) || s.bgVideo))
        ? '<div class="section-title">背景来源</div>' +
          '<div style="display:flex;gap:8px;margin:0 2px 4px">' +
            [['auto', '自动'], ['image', '用图片'], ['video', '用视频']].map(function (o) {
              var cur = s.bgSource || 'auto';
              var on = cur === o[0];
              return '<button class="chip' + (on ? ' on' : '') + '" style="flex:1;text-align:center" data-act="set-bg-source" data-v="' + o[0] + '">' + o[1] + '</button>';
            }).join('') +
          '</div>'
        : '') +
      '<div class="section-title">背景图</div>' +
      '<div class="list">' +
        '<div class="row">' +
          '<span class="ic" style="overflow:hidden;' + (s.bgImage ? 'background-image:url(' + s.bgImage + ');background-size:cover;background-position:center' : '') + '">' + (s.bgImage ? '' : icon('grid')) + '</span>' +
          '<span class="tx"><span class="t">首页背景</span><span class="s">' + (s.bgImage ? '已设置相册照片' : '默认水彩背景') + '</span></span>' +
          (s.bgImage ? '<button class="icon-btn plain" data-act="clear-bg" aria-label="恢复默认">' + icon('trash', 'sm') + '</button>' : '') +
          '<button class="btn" style="height:34px;padding:0 14px" data-act="pick-bg">从相册选</button>' +
        '</div>' +
        '<div class="row" style="display:block">' +
          '<div style="display:flex;align-items:baseline;gap:8px;margin-bottom:2px">' +
            '<span style="font-size:14.5px;font-weight:500">毛玻璃强度</span>' +
            '<span style="font-size:11.5px;color:var(--ink-3);flex:1">' + (s.bgImage ? '左右拖动调节' : '选一张背景图后可调') + '</span>' +
            '<span id="bg-slider-val" style="font-size:12.5px;color:var(--accent-ink);min-width:44px;text-align:right">' + blurPx(s) + ' px</span>' +
          '</div>' +
          '<input type="range" id="bg-slider" class="range" min="0" max="20" step="1" value="' + blurPx(s) + '"' + (s.bgImage ? '' : ' disabled') + '>' +
        '</div>' +
        (global.AndroidBridge && global.AndroidBridge.pickBigVideo
          ? '<div class="row">' +
              '<span class="ic">' + icon('world') + '</span>' +
              '<span class="tx"><span class="t">大视频背景（GB 级）</span><span class="s">' +
                ((s.bigVideos && s.bigVideos.length) ? ('已导入 ' + s.bigVideos.length + ' 段，可直接播放') : '从相册选一个长视频，拷进 App 内播放') +
              '</span></span>' +
              '<button class="btn" style="height:34px;padding:0 14px" data-act="pick-big-video">选择</button>' +
            '</div>'
          : '') +
        '<div class="row">' +
          '<span class="ic">' + icon('camera') + '</span>' +
          '<span class="tx"><span class="t">背景视频</span><span class="s">' + (s.bgVideo ? ('已设置 ' + ((s.bgVideoIds || []).length || 1) + ' 段，循环播放（不进备份）') : '可选，可多选几段轮换（建议单段 200MB 内）') + '</span></span>' +
          (s.bgVideo ? '<button class="icon-btn plain" data-act="clear-video" aria-label="移除">' + icon('trash', 'sm') + '</button>' : '') +
          '<button class="btn" style="height:34px;padding:0 14px" data-act="pick-video">选择视频</button>' +
        '</div>' +
        '<input type="file" id="video-input" accept="video/*" multiple hidden>' +
        '<div class="row">' +
          '<span class="ic" style="overflow:hidden;' + (s.fabImage ? 'background-image:url(' + s.fabImage + ');background-size:cover;background-position:center' : '') + '">' + (s.fabImage ? '' : icon('plus')) + '</span>' +
          '<span class="tx"><span class="t">加号按钮图片</span><span class="s">' + (s.fabImage ? '已换成你的照片（无十字）' : '默认橙色加号') + '</span></span>' +
          (s.fabImage ? '<button class="icon-btn plain" data-act="clear-fab" aria-label="恢复默认">' + icon('trash', 'sm') + '</button>' : '') +
          '<button class="btn" style="height:34px;padding:0 14px" data-act="pick-fab">从相册选</button>' +
        '</div>' +
      '</div>' +
      '<input type="file" id="bg-input" accept="image/*" hidden>' +
      '<input type="file" id="fab-input" accept="image/*" hidden>' +

      '<div class="section-title">往年今日提醒</div>' +
      '<div class="list">' +
        '<div class="row"><span class="ic">' + icon('bell') + '</span>' +
          '<span class="tx"><span class="t">每天提醒我看往年今日</span>' +
          '<span class="s">' + (global.AndroidBridge ? '到点推送系统通知' : '打开 App 时弹出提醒，打包成 APK 后可定时推送') + '</span></span>' +
          '<button class="switch' + (s.reminder && s.reminder.enabled ? ' on' : '') + '" data-act="toggle-reminder" role="switch" aria-checked="' + (s.reminder && s.reminder.enabled ? 'true' : 'false') + '"><span></span></button></div>' +
        '<div class="row"><span class="tx"><span class="t">提醒时间</span><span class="s">每天到点提醒一次</span></span>' +
          '<input class="rem-time" type="time" id="rem-time" value="' + esc((s.reminder && s.reminder.time) || '21:00') + '"></div>' +
      '</div>' +

      '<div class="section-title">主题色</div>' +
      '<div class="swatches">' +
        Object.keys(App.ACCENTS).map(function (k) {
          var a = App.ACCENTS[k];
          return '<button class="swatch' + ((s.accent || 'peach') === k ? ' on' : '') + '" data-act="set-accent" data-k="' + k + '" ' +
            'style="background:' + a.a + '" aria-label="' + k + '"></button>';
        }).join('') +
      '</div>' +
      '<div class="section-title">字号</div>' +
      '<div class="list">' +
        '<div style="display:flex;gap:10px">' +
          [[0.93, '小'], [1, '标准'], [1.08, '大'], [1.16, '特大']].map(function (f) {
            var on = Math.abs((s.fontScale || 1) - f[0]) < 0.01;
            return '<button class="chip' + (on ? ' on' : '') + '" style="flex:1;text-align:center" data-act="set-font" data-v="' + f[0] + '">' + f[1] + '</button>';
          }).join('') +
        '</div>' +
      '</div>' +
      '<div class="section-title">其他</div>' +
      '<div class="list">' +
        '<button class="row" data-act="nav" data-to="/data"><span class="ic">' + icon('box') + '</span>' +
          '<span class="tx"><span class="t">数据管理</span><span class="s">备份与恢复</span></span>' +
          '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
        '<button class="row" data-act="about"><span class="ic">' + icon('heart') + '</span>' +
          '<span class="tx"><span class="t">关于</span><span class="s">时光手记 · 本地日记</span></span>' +
          '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
      '</div>' +
      '<div class="detail-foot" style="margin-top:28px">所有内容只保存在这台设备上<br>换手机前记得先导出备份</div>' +
      '</div>';
  };

  App.act('rename-app', function () {
    var cur = (App.state.settings && App.state.settings.appTitle) || '时光手记';
    var v = global.prompt('给这个日记本起个名字', cur);
    if (v === null) return;
    v = String(v).trim();
    App.state.settings.appTitle = v || '时光手记';
    App.save();
    App.render();
    U.toast('已更新');
  });

  App.act('toggle-reminder', function () {
    var s = App.state.settings;
    s.reminder = s.reminder || { enabled: false, time: '21:00' };
    s.reminder.enabled = !s.reminder.enabled;
    if (s.reminder.enabled) App.requestNotifyPermission();
    App.save();
    App.render();
    U.toast(s.reminder.enabled ? '已开启每日提醒' : '已关闭每日提醒');
  });

  App.act('set-theme', function (el) {
    var k = el.dataset.k;
    App.state.settings.theme = (k === 'warm') ? '' : k;
    App.save();
    App.render();
    U.toast('已切换风格');
  });



  App.act('pick-big-video', function () {
    if (global.AndroidBridge && global.AndroidBridge.pickBigVideo) {
      U.toast('正在打开相册…');
      global.AndroidBridge.pickBigVideo();
    } else {
      U.toast('打包成 APK 后才能用');
    }
  });

  App.act('pick-video', function () {
    var input = U.el('video-input');
    if (input) { input.value = ''; input.click(); }
  });

  App.act('clear-video', function () {
    var ids = (App.state.settings.bgVideoIds || []).slice();
    ids.forEach(function (id) { Store.removeMedia(id === 0 ? 'bgVideo' : 'bgVideo:' + id); });
    (App.state.settings.bigVideos || []).forEach(function (v) {
      if (global.AndroidBridge && global.AndroidBridge.deleteBigVideo) {
        try { global.AndroidBridge.deleteBigVideo(v.id); } catch (e) { }
      }
    });
    App.state.settings.bigVideos = [];
    App.state.settings.bgVideoIds = [];
    App.state.settings.bgVideoIdx = 0;
    App.state.settings.bgVideo = false;
    Store.removeMedia('bgVideo');
    App.save();
    App.applySettings();
    App.render();
    U.toast('已移除视频背景');
  });

  App.act('pick-bg', function () {
    var input = U.el('bg-input');
    if (input) { input.value = ''; input.click(); }
  });

  App.act('pick-fab', function () {
    var input = U.el('fab-input');
    if (input) { input.value = ''; input.click(); }
  });

  App.act('clear-fab', function () {
    App.state.settings.fabImage = '';
    App.save();
    App.applySettings();
    App.render();
    U.toast('已恢复默认加号');
  });

  App.act('clear-bg', function () {
    App.state.settings.bgImage = '';
    App.save();
    App.applySettings();
    App.render();
    U.toast('已恢复默认背景');
  });

  App.act('set-accent', function (el) {    App.state.settings.accent = el.dataset.k;
    App.save();
    App.render();
  });

  App.act('set-font', function (el) {
    App.state.settings.fontScale = Number(el.dataset.v);
    App.save();
    App.render();
  });

  App.act('about', function () {
    U.openSheet('<div class="sheet-head"><div class="t">时光手记</div><button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body" style="font-size:14px;line-height:1.9;color:var(--ink-2);padding:8px 20px 24px">' +
      '<p>一个只属于你的生活时间线。</p>' +
      '<p style="margin-top:8px">按日期记录每天的小事，把它串成一条线；把重要的日子放进纪念日；写一段话给后来的自己。</p>' +
      '<p style="margin-top:8px">数据保存在浏览器本地存储中，不会上传到任何服务器。清理浏览器数据前，请先在「数据管理」里导出备份。</p>' +
      '<p style="margin-top:8px;color:var(--ink-3);font-size:12px">版本 1.0 · 参考「人生时间线」的界面思路自制</p>' +
      '</div>');
  });

  /* ---------------- 用户信息 ---------------- */
  App.screens.profile = function () {
    var p = App.state.profile || {};
    var diaries = App.state.entries.filter(function (e) { return e.type !== 'event'; }).length;
    var eventsCount = App.state.entries.filter(function (e) { return e.type === 'event'; }).length;
    var avatar = p.avatarImage
      ? '<img src="' + esc(p.avatarImage) + '" alt="">'
      : '<span class="em">' + esc(p.avatar || '🌿') + '</span>';
    function row(title, value) {
      return '<div class="row"><span class="tx"><span class="t">' + title + '</span></span>' +
        '<span class="val">' + value + '</span></div>';
    }
    return '<div class="screen">' +
      '<header class="topbar">' +
        '<div class="slot left"><button class="icon-btn plain" data-act="back">' + icon('back') + '</button></div>' +
        '<div class="title">用户信息</div>' +
        '<div class="slot"><button class="text-btn strong" data-act="save-profile">完成</button></div>' +
      '</header>' +
      '<div class="profile-edit">' +
        '<button class="avatar-big" data-act="change-avatar" aria-label="更换头像">' + avatar +
          '<span class="cam">' + icon('camera', 'sm') + '</span></button>' +
        '<div class="pf-field"><div class="lb">昵称</div>' +
          '<input id="pf-name" value="' + esc(p.nickname || '我') + '" placeholder="昵称" maxlength="16"></div>' +
        '<div class="hint">头像和昵称只保存在这台设备中</div>' +
      '</div>' +
      '<div class="section-title">我的记录</div>' +
      '<div class="list">' +
        row('日记篇数', diaries + ' 篇') +
        row('事件个数', eventsCount + ' 个') +
        row('纪念日数', App.state.anniversaries.length + ' 个') +
        row('记录天数', App.countDays() + ' 天') +
      '</div>' +
      '<input type="file" id="avatar-input" accept="image/*" hidden>' +
      '<input type="file" id="avatar-camera" accept="image/*" capture="environment" hidden>' +
      '</div>';
  };

  App.act('change-avatar', function () {
    U.openSheet('<div class="sheet-head"><div class="t">更换头像</div>' +
      '<button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body">' +
      '<button class="sheet-row" data-act="avatar-shoot">' + icon('camera') + '<span class="t">拍一张</span></button>' +
      '<button class="sheet-row" data-act="avatar-pick">' + icon('grid') + '<span class="t">从相册选择</span></button>' +
      '<button class="sheet-row" data-act="avatar-emoji">' + icon('heart') + '<span class="t">用表情代替</span></button>' +
      '</div>');
  });

  App.act('avatar-shoot', function () {
    U.closeSheet();
    var el = U.el('avatar-camera');
    if (el) el.click();
  });

  App.act('avatar-pick', function () {
    U.closeSheet();
    var el = U.el('avatar-input');
    if (el) el.click();
  });

  App.act('avatar-emoji', function () {
    U.openSheet('<div class="sheet-head"><div class="t">选一个头像</div>' +
      '<button class="x" data-act="close-sheet">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body"><div style="display:grid;grid-template-columns:repeat(6,1fr);gap:8px">' +
      EMOJIS.map(function (e) {
        return '<button style="font-size:26px;height:52px;border-radius:14px;background:rgba(255,255,255,.7)" data-act="set-avatar" data-emoji="' + e + '">' + e + '</button>';
      }).join('') + '</div></div>');
  });

  App.act('set-avatar', function (el) {
    App.state.profile.avatar = el.dataset.emoji;
    App.state.profile.avatarImage = '';
    App.save();
    U.closeSheet();
    App.render();
  });

  App.act('save-profile', function () {
    var name = ((U.el('pf-name') || {}).value || '').trim();
    App.state.profile.nickname = name || '我';
    App.save();
    U.toast('已保存');
    App.back();
  });

  /* ---------------- 数据管理 ---------------- */
  function sizeText() {
    try {
      var s = JSON.stringify(App.state);
      var kb = s.length / 1024;
      return kb > 1024 ? (kb / 1024).toFixed(1) + ' MB' : Math.round(kb) + ' KB';
    } catch (e) { return '—'; }
  }

  App.screens.data = function () {
    var photos = 0;
    App.state.entries.forEach(function (e) { photos += (e.photos || []).length; });
    return '<div class="screen">' +
      '<header class="topbar">' +
        '<div class="slot left"><button class="icon-btn plain" data-act="back">' + icon('back') + '</button></div>' +
        '<div class="title">数据管理</div><div class="slot"></div></header>' +
      '<div class="list">' +
        '<div class="row plain"><span class="tx"><span class="t">' + App.state.entries.length + ' 条记录 · ' + App.countDays() + ' 个日子</span>' +
          '<span class="s">' + photos + ' 张照片 · 约 ' + sizeText() + '</span></span></div>' +
        '<button class="row" data-act="export-data"><span class="ic">' + icon('download') + '</span>' +
          '<span class="tx"><span class="t">导出备份</span><span class="s">存成 JSON 文件，可放网盘或电脑</span></span>' +
          '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
        '<button class="row" data-act="import-data"><span class="ic">' + icon('upload') + '</span>' +
          '<span class="tx"><span class="t">导入备份</span><span class="s">用之前导出的文件恢复</span></span>' +
          '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
        '<button class="row" data-act="clear-data"><span class="ic">' + icon('trash') + '</span>' +
          '<span class="tx"><span class="t">清空全部数据</span><span class="s">包括示例记录，无法恢复</span></span>' +
          '<span class="chev">' + icon('chev', 'sm') + '</span></button>' +
      '</div>' +
      '<input type="file" id="import-input" accept="application/json,.json" hidden>' +
      '<div class="detail-foot" style="margin-top:26px">数据保存在本机浏览器存储里<br>清理浏览器数据会一起被清掉，记得定期导出</div>' +
      '</div>';
  };

  App.act('export-data', function () {
    var payload = {
      app: 'timeline-diary',
      version: 1,
      exportedAt: new Date().toISOString(),
      state: App.state
    };
    var name = '时光手记-备份-' + today() + '.json';
    U.download(name, JSON.stringify(payload, null, 2), 'application/json');
    U.toast('备份已导出');
  });

  App.act('import-data', function () {
    var input = U.el('import-input');
    if (!input) return;
    input.value = '';
    input.click();
  });

  App.act('clear-data', function () {
    U.confirmSheet('清空全部数据？', '所有日记、照片和纪念日都会被删除，且无法恢复。建议先导出备份。', '我确定，清空', function () {
      var blank = Store.seed();
      blank.entries = [];
      blank.anniversaries = [];
      blank.settings.seeded = false;
      Store.replaceAll(blank).then(function () {
        location.hash = '';
        location.reload();
      });
    }, true);
  });

  /* ---------------- 整理 ---------------- */
  App.screens.manage = function () {
    var tags = App.state.tags || [];
    var books = App.state.notebooks || [];
    var counts = {};
    App.state.entries.forEach(function (e) {
      (e.tags || []).forEach(function (t) { counts[t] = (counts[t] || 0) + 1; });
    });
    return '<div class="screen">' +
      '<header class="topbar">' +
        '<div class="slot left"><button class="icon-btn plain" data-act="back">' + icon('back') + '</button></div>' +
        '<div class="title">整理</div><div class="slot"></div></header>' +
      '<div class="section-title">标签</div>' +
      '<div class="list">' +
        (tags.length ? tags.map(function (t) {
          return '<div class="row"><span class="ic">' + icon('tag', 'sm') + '</span>' +
            '<span class="tx"><span class="t">' + esc(t) + '</span><span class="s">' + (counts[t] || 0) + ' 条记录</span></span>' +
            '<button class="icon-btn plain" data-act="del-tag" data-name="' + esc(t) + '">' + icon('trash', 'sm') + '</button></div>';
        }).join('') : '<div class="empty" style="margin:10px 0"><div class="t">还没有标签</div></div>') +
        '<div style="display:flex;gap:8px"><input id="mg-tag" placeholder="新标签" style="flex:1;height:42px;padding:0 14px;border-radius:14px;background:rgba(255,255,255,.8)">' +
        '<button class="btn" data-act="add-tag">添加</button></div>' +
      '</div>' +
      '<div class="section-title">本子</div>' +
      '<div class="list">' +
        books.map(function (b) {
          var n = App.state.entries.filter(function (e) { return e.notebook === b; }).length;
          return '<div class="row"><span class="ic">' + icon('book', 'sm') + '</span>' +
            '<span class="tx"><span class="t">' + esc(b) + '</span><span class="s">' + n + ' 条记录</span></span>' +
            '<button class="icon-btn plain" data-act="del-book" data-name="' + esc(b) + '">' + icon('trash', 'sm') + '</button></div>';
        }).join('') +
        '<div style="display:flex;gap:8px"><input id="mg-book" placeholder="新本子名称" style="flex:1;height:42px;padding:0 14px;border-radius:14px;background:rgba(255,255,255,.8)">' +
        '<button class="btn" data-act="add-book">添加</button></div>' +
      '</div></div>';
  };

  App.act('add-tag', function () {
    var v = ((U.el('mg-tag') || {}).value || '').trim();
    if (!v) return;
    if (App.state.tags.indexOf(v) < 0) App.state.tags.push(v);
    App.save();
    App.render();
  });

  App.act('del-tag', function (el) {
    var name = el.dataset.name;
    U.confirmSheet('删除标签「' + name + '」？', '记录本身不会删除，只是不再带这个标签。', '删除', function () {
      App.state.tags = App.state.tags.filter(function (t) { return t !== name; });
      App.state.entries.forEach(function (e) {
        e.tags = (e.tags || []).filter(function (t) { return t !== name; });
      });
      App.save();
      App.render();
    }, true);
  });

  App.act('add-book', function () {
    var v = ((U.el('mg-book') || {}).value || '').trim();
    if (!v) return;
    if (App.state.notebooks.indexOf(v) < 0) App.state.notebooks.push(v);
    App.save();
    App.render();
  });

  App.act('del-book', function (el) {
    var name = el.dataset.name;
    U.confirmSheet('删除本子「' + name + '」？', '里面的记录会移到第一个本子。', '删除', function () {
      App.state.notebooks = App.state.notebooks.filter(function (b) { return b !== name; });
      var first = App.state.notebooks[0] || '小本子';
      App.state.entries.forEach(function (e) { if (e.notebook === name) e.notebook = first; });
      App.save();
      App.render();
    }, true);
  });

  /* ---------------- 输入绑定 ---------------- */
  document.addEventListener('input', function (ev) {
    var t = ev.target;
    if (t && t.id === 'bg-slider') {
      var v = Number(t.value);
      App.state.settings.bgBlurPx = v;
      App.applySettings();
      var lab = U.el('bg-slider-val');
      if (lab) lab.textContent = v + ' px';
      return;
    }
    if (!t || !t.dataset || !t.dataset.field || !App.draft) return;
    var f = t.dataset.field;
    if (f === 'photos') return;
    App.draft[f] = t.value;
  });

  document.addEventListener('change', function (ev) {
    var t = ev.target;
    if (!t) return;
    if (t.id === 'photo-input' || t.id === 'camera-input') {
      handleFiles(t.files);
      return;
    }
    if (t.id === 'avatar-input' || t.id === 'avatar-camera') {
      if (t.files && t.files[0]) {
        U.compressImage(t.files[0], 512, 0.8).then(function (res) {
          App.state.profile.avatarImage = res.data;
          App.save();
          App.render();
          U.toast('头像已更新');
        }).catch(function () {
          U.toast('头像处理失败');
        });
      }
      return;
    }
    if (t.id === 'bg-slider') {
      App.state.settings.bgBlurPx = Number(t.value);
      App.save();
      return;
    }
    if (t.id === 'video-input') {
      var files = t.files ? Array.prototype.slice.call(t.files) : [];
      if (!files.length) return;
      var okFiles = files.filter(function (f) { return f.size <= 400 * 1024 * 1024; });
      if (!okFiles.length) {
        U.toast('单个视频请控制在 400MB 以内');
        return;
      }
      U.toast('正在导入 ' + okFiles.length + ' 段视频…');
      var ids = (App.state.settings.bgVideoIds || []).slice();
      var nextId = ids.length ? Math.max.apply(null, ids) + 1 : 0;
      var done = 0;
      var failed = 0;
      okFiles.forEach(function (f, i) {
        var id = nextId + i;
        /* 直接存 Blob：不做 base64，不整段读进内存 */
        Store.putMedia(id === 0 ? 'bgVideo' : 'bgVideo:' + id, f).then(function () {
          ids.push(id);
          done++;
        }).catch(function () {
          failed++;
        }).then(function () {
          if (done + failed === okFiles.length) {
            if (done) {
              App.state.settings.bgVideoIds = ids;
              App.state.settings.bgVideo = true;
              App.state.settings.bgVideoIdx = Math.max(0, ids.length - done);
              App.save();
              App.applySettings();
              App.render();
              U.toast('已添加 ' + done + ' 段视频' + (failed ? '（' + failed + ' 段失败）' : ''));
            } else {
              U.toast('导入失败：手机存储空间可能不足');
            }
          }
        });
      });
      return;
    }
    if (t.id === 'fab-input') {
      if (t.files && t.files[0]) {
        U.compressImage(t.files[0], 400, 0.85).then(function (res) {
          App.state.settings.fabImage = res.data;
          App.save();
          App.applySettings();
          App.render();
          U.toast('加号已换成照片');
        }).catch(function () {
          U.toast('图片处理失败');
        });
      }
      return;
    }
    if (t.id === 'bg-input') {
      if (t.files && t.files[0]) {
        var lsModeBg = Store.mode && Store.mode() === 'ls';
        U.compressImage(t.files[0], lsModeBg ? 900 : 1200, lsModeBg ? 0.7 : 0.78).then(function (res) {
          App.state.settings.bgImage = res.data;
          App.save();
          App.applySettings();
          App.render();
          U.toast('背景已更新');
        }).catch(function () {
          U.toast('图片处理失败');
        });
      }
      return;
    }
    if (t.id === 'world-date') {
      App.worldDate = t.value || '';
      App.render();
      return;
    }
    if (t.id === 'rem-time') {
      var s2 = App.state.settings;
      s2.reminder = s2.reminder || { enabled: false, time: '21:00' };
      s2.reminder.time = t.value || '21:00';
      App.save();
      App.syncReminder();
      U.toast('提醒时间已设为 ' + s2.reminder.time);
      return;
    }
    if (t.id === 'import-input' && t.files && t.files[0]) {
      var file = t.files[0];
      U.readFileAsText(file).then(function (txt) {
        var data = JSON.parse(txt);
        var st = data && data.state ? data.state : data;
        if (!st || !Array.isArray(st.entries)) throw new Error('不是有效的备份文件');
        U.confirmSheet('导入备份？', '会用备份里的 ' + st.entries.length + ' 条记录覆盖当前全部数据。', '导入并覆盖', function () {
          Store.replaceAll(Store.normalize(st)).then(function () {
            U.toast('已导入');
            setTimeout(function () { location.hash = ''; location.reload(); }, 400);
          });
        });
      }).catch(function (e) {
        U.toast('导入失败：' + (e.message || '文件格式不对'));
      });
    }
  });

  /* ---------------- 细节 ---------------- */
  App.afterRender = function (name) {
    if (name === 'new' || name === 'edit' || name === 'editor') {
      var ta = U.el('content');
      if (ta) {
        ta.style.height = 'auto';
        ta.style.height = Math.max(120, ta.scrollHeight) + 'px';
        if (!ta.value) ta.focus();
      }
      var letter = U.el('letter-input');
      if (letter && !letter.hidden && !letter.value) letter.focus();
    }
  };

  /* Service Worker（仅在 https / localhost 下生效；nosw=1 用于调试时绕过缓存）
     原生 App 里页面资源本身就打包在安装包里，不需要再套一层缓存 */
  if ('serviceWorker' in navigator) {
    var noSw = String(location.search).indexOf('nosw=1') >= 0 ||
      String(location.search).indexOf('native=1') >= 0;
    if (noSw) {
      navigator.serviceWorker.getRegistrations().then(function (rs) {
        rs.forEach(function (r) { r.unregister(); });
      }).catch(function () { });
      if (global.caches && caches.keys) {
        caches.keys().then(function (keys) {
          keys.forEach(function (k) { caches.delete(k); });
        }).catch(function () { });
      }
    } else if (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
      window.addEventListener('load', function () {
        navigator.serviceWorker.register('sw.js').catch(function () { });
      });
    }
  }
})(window);
