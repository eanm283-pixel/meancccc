/* 通用 UI 小工具 */
(function (global) {
  'use strict';

  var WEEK = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

  function el(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function icon(name, cls) {
    return '<svg class="icon ' + (cls || '') + '" aria-hidden="true"><use href="#i-' + name + '"></use></svg>';
  }

  function cnDate(s) {
    var p = String(s).split('-');
    return Number(p[0]) + '年' + Number(p[1]) + '月' + Number(p[2]) + '日';
  }

  function mdDate(s) {
    var p = String(s).split('-');
    return Number(p[1]) + '月' + Number(p[2]) + '日';
  }

  function weekday(s) {
    return WEEK[Store.parseDate(s).getDay()];
  }

  function daysText(s) {
    var d = Store.dayDiff(s);
    if (d === 0) return '今天';
    if (d === 1) return '昨天';
    if (d === -1) return '明天';
    return Math.abs(d) + ' 天' + (d > 0 ? '' : '后');
  }

  function relTime(iso) {
    if (!iso) return '';
    var t = new Date(iso).getTime();
    if (!t) return '';
    var diff = Date.now() - t;
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + ' 分钟前';
    if (diff < 86400000) return Math.floor(diff / 3600000) + ' 小时前';
    var d = new Date(iso);
    return (d.getMonth() + 1) + '月' + d.getDate() + '日';
  }

  var toastTimer = null;
  function toast(msg) {
    var t = el('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 1900);
  }

  var sheetOpen = false;

  function openSheet(html, opts) {
    var sheet = el('sheet'), overlay = el('overlay');
    sheet.innerHTML = '<div class="sheet-grip"></div>' + html;
    sheet.hidden = false;
    overlay.hidden = false;
    sheetOpen = true;
    document.body.style.overflow = 'hidden';
    if (opts && opts.onMount) opts.onMount(sheet);
  }

  function closeSheet() {
    var sheet = el('sheet'), overlay = el('overlay');
    if (sheet) { sheet.hidden = true; sheet.innerHTML = ''; }
    if (overlay) overlay.hidden = true;
    sheetOpen = false;
    document.body.style.overflow = '';
  }

  function isSheetOpen() { return sheetOpen; }

  function confirmSheet(title, text, okText, onOk, danger) {
    openSheet(
      '<div class="sheet-head"><div class="t">' + esc(title) + '</div>' +
      '<button class="x" data-act="close-sheet" aria-label="关闭">' + icon('close', 'sm') + '</button></div>' +
      '<div class="sheet-body">' +
      (text ? '<p style="padding:2px 8px 16px;color:var(--ink-2);font-size:14px;line-height:1.7">' + esc(text) + '</p>' : '') +
      '<button class="btn block ' + (danger ? 'danger' : 'primary') + '" data-act="confirm-ok">' + esc(okText || '确定') + '</button>' +
      '<button class="btn block" style="margin-top:10px" data-act="close-sheet">取消</button>' +
      '</div>'
    );
    el('sheet').querySelector('[data-act="confirm-ok"]').addEventListener('click', function () {
      closeSheet();
      if (onOk) onOk();
    });
  }

  function viewPhoto(src) {
    var box = document.createElement('div');
    box.className = 'viewer';
    box.innerHTML = '<img src="' + esc(src) + '" alt="">' +
      '<button class="close" aria-label="关闭">' + icon('close') + '</button>';
    box.addEventListener('click', function () { box.remove(); });
    document.body.appendChild(box);
  }

  /* 压缩图片为 dataURL */
  function compressImage(file, maxSize, quality) {
    maxSize = maxSize || 1600;
    quality = quality || 0.82;
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () {
        var img = new Image();
        img.onload = function () {
          var w = img.naturalWidth, h = img.naturalHeight;
          var scale = Math.min(1, maxSize / Math.max(w, h));
          var cw = Math.round(w * scale), ch = Math.round(h * scale);
          var canvas = document.createElement('canvas');
          canvas.width = cw; canvas.height = ch;
          var ctx = canvas.getContext('2d');
          ctx.fillStyle = '#fff';
          ctx.fillRect(0, 0, cw, ch);
          ctx.drawImage(img, 0, 0, cw, ch);
          try {
            resolve({ data: canvas.toDataURL('image/jpeg', quality), w: cw, h: ch });
          } catch (e) { reject(e); }
        };
        img.onerror = function () { reject(new Error('图片读取失败')); };
        img.src = String(reader.result);
      };
      reader.onerror = function () { reject(new Error('文件读取失败')); };
      reader.readAsDataURL(file);
    });
  }

  function download(filename, text, mime) {
    if (global.AndroidBridge && global.AndroidBridge.saveBackup) {
      try {
        global.AndroidBridge.saveBackup(filename, text);
        toast('备份已保存到手机「下载」目录');
        return;
      } catch (e) { }
    }
    var blob = new Blob([text], { type: mime || 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 800);
  }

  function readFileAsText(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(String(r.result)); };
      r.onerror = function () { reject(new Error('读取失败')); };
      r.readAsText(file);
    });
  }

  global.UI = {
    WEEK: WEEK,
    el: el,
    esc: esc,
    icon: icon,
    cnDate: cnDate,
    mdDate: mdDate,
    weekday: weekday,
    daysText: daysText,
    relTime: relTime,
    toast: toast,
    openSheet: openSheet,
    closeSheet: closeSheet,
    isSheetOpen: isSheetOpen,
    confirmSheet: confirmSheet,
    viewPhoto: viewPhoto,
    compressImage: compressImage,
    download: download,
    readFileAsText: readFileAsText
  };
})(window);
