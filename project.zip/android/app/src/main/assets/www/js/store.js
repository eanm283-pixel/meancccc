/* 数据层：IndexedDB 优先，localStorage 兜底 —— 无依赖 */
(function (global) {
  'use strict';

  var DB_NAME = 'timeline-diary';
  var DB_VER = 1;
  var STORE = 'kv';
  var KEY = 'state';
  var LS_KEY = 'timeline-diary-state-v1';
  var memory = null;
  var idb = null;
  var connecting = null;
  var idbFailed = false;
  var mode = 'pending';

  function openIDB() {
    // file:// 下 Chrome 的 IndexedDB 不可用，直接用 localStorage，避免等待
    if (global.location && global.location.protocol === 'file:') {
      idbFailed = true;
      mode = 'ls';
      return Promise.reject(new Error('file protocol'));
    }
    if (!global.indexedDB) {
      idbFailed = true;
      mode = 'ls';
      return Promise.reject(new Error('no indexedDB'));
    }
    var req;
    try { req = global.indexedDB.open(DB_NAME, DB_VER); }
    catch (e) { idbFailed = true; mode = 'ls'; return Promise.reject(e); }

    var slow = false;
    return new Promise(function (resolve, reject) {
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = function () {
        idb = req.result;
        idbFailed = false;
        mode = 'idb';
        resolve(idb);
        // 连接迟到（先用了 localStorage）：把内存里的数据补写回 IndexedDB
        if (slow && memory) {
          try { idbSetFrom(idb, KEY, JSON.parse(JSON.stringify(memory))); } catch (e) { }
        }
      };
      req.onerror = function () {
        idbFailed = true; mode = 'ls';
        reject(req.error || new Error('idb open error'));
      };
      req.onblocked = function () {
        idbFailed = true; mode = 'ls';
        reject(new Error('idb blocked'));
      };
      // 打不开时先用本地缓存把界面跑起来，连接成功后再补写回去
      setTimeout(function () {
        if (!idb) {
          slow = true;
          idbFailed = true;
          mode = 'ls';
          reject(new Error('idb slow'));
        }
      }, 4000);
    });
  }

  function idbSetFrom(db, key, val) {
    var tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(val, key);
  }

  function getDB() {
    if (idb) return Promise.resolve(idb);
    if (idbFailed) return Promise.reject(new Error('indexedDB unavailable'));
    if (!connecting) connecting = openIDB();
    return connecting;
  }

  function idbGet(key) {
    return getDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readonly');
        var req = tx.objectStore(STORE).get(key);
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { reject(req.error); };
      });
    });
  }

  function idbSet(key, val) {
    return getDB().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readwrite');
        tx.objectStore(STORE).put(val, key);
        tx.oncomplete = function () { resolve(true); };
        tx.onerror = function () { reject(tx.error); };
      });
    });
  }

  function lsGet() {
    try {
      var raw = global.localStorage.getItem(LS_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }

  function lsSet(val) {
    try {
      global.localStorage.setItem(LS_KEY, JSON.stringify(val));
      return true;
    } catch (e) { return false; }
  }

  /* ---------------- 工具 ---------------- */
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function dateStr(d) {
    d = d || new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  function timeStr(d) {
    d = d || new Date();
    return pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function parseDate(s) {
    var p = String(s || '').split('-');
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]), 12, 0, 0);
  }

  function dayDiff(from, to) {
    var a = parseDate(from), b = parseDate(to || dateStr());
    return Math.round((b - a) / 86400000);
  }

  function uid(prefix) {
    return (prefix || 'e') + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  /* ---------------- 初始数据 ---------------- */
  function seed() {
    var now = new Date();
    var today = dateStr(now);
    var y = now.getFullYear();
    var entries = [
      {
        id: uid('e'), type: 'diary', date: today, time: '22:40',
        title: '第一次用时光手记',
        content: '把今天的自己留在这里。以后回头看，应该会记得这个有点普通的晚上。',
        mood: 1, emoji: '🌱', photos: [], tags: ['日常'], notebook: '小本子',
        linkedEventId: '', letter: '', createdAt: now.toISOString(), updatedAt: now.toISOString()
      },
      {
        id: uid('e'), type: 'diary', date: '2026-05-29', time: '03:32',
        title: '日记', content: '宠物',
        mood: 2, emoji: '🐱', photos: ['assets/demo-pet.jpg'], tags: [], notebook: '小本子',
        linkedEventId: '', letter: '', createdAt: '2026-05-29T03:32:00.000Z', updatedAt: '2026-05-29T03:32:00.000Z'
      },
      {
        id: uid('e'), type: 'diary', date: '2018-11-12', time: '21:10',
        title: '在家里宅了一天',
        content: '哪儿也没去，抱着猫看了一整天剧。窗外下雨，屋里很暖。',
        mood: 2, emoji: '🙈', photos: [], tags: ['纪念'], notebook: '小本子',
        linkedEventId: '', letter: '', createdAt: '2018-11-12T21:10:00.000Z', updatedAt: '2018-11-12T21:10:00.000Z'
      },
      {
        id: uid('e'), type: 'diary', date: '2018-11-01', time: '08:20',
        title: '第一次去土耳其',
        content: '凌晨四点起床，热气球在晨雾里一盏一盏亮起来，像有人把星星挂在地面上。',
        mood: 0, emoji: '🎈', photos: ['assets/demo-balloon.jpg'], tags: ['纪念', '旅行'], notebook: '旅行',
        linkedEventId: '', letter: '如果十年后再看到这条，希望你还有说走就走的勇气。',
        createdAt: '2018-11-01T08:20:00.000Z', updatedAt: '2018-11-01T08:20:00.000Z'
      },
      {
        id: uid('e'), type: 'diary', date: dateStr(new Date(now.getFullYear() - 1, now.getMonth(), now.getDate())),
        time: '20:15', title: '去年的今天',
        content: '在河边走了很久，捡了一颗圆圆的小石头带回家。那天风很大，但心里很安静。',
        mood: 2, emoji: '🍂', photos: [], tags: ['日常'], notebook: '小本子',
        linkedEventId: '', letter: '', createdAt: now.toISOString(), updatedAt: now.toISOString()
      },
      {
        id: uid('e'), type: 'event', date: y + '-09-25', time: '15:00',
        title: '搬进新家',
        content: '拿到钥匙的那天，阳光从客厅地板上慢慢挪过去。',
        mood: 0, emoji: '🏡', photos: [], tags: ['纪念'], notebook: '小本子',
        linkedEventId: '', letter: '', createdAt: now.toISOString(), updatedAt: now.toISOString()
      }
    ];

    return {
      version: 1,
      profile: { nickname: '我', avatar: '🌿', joinedAt: now.toISOString() },
      entries: entries,
      anniversaries: [
        { id: uid('a'), title: '和 TA 在一起', date: '2019-05-20', emoji: '💞', note: '', repeat: true },
        { id: uid('a'), title: '搬来这座城市', date: '2016-09-01', emoji: '🏙', note: '', repeat: false }
      ],
      tags: ['纪念', '旅行', '日常', '家人', '工作', '宠物'],
      notebooks: ['小本子', '旅行', '家人', '工作'],
      settings: { accent: 'peach', fontScale: 1, seeded: true, view: 'all', reminder: { enabled: true, time: '21:00' } },
      meta: { createdAt: now.toISOString(), updatedAt: now.toISOString() }
    };
  }

  function normalize(state) {
    if (!state || typeof state !== 'object') return null;
    state.entries = Array.isArray(state.entries) ? state.entries : [];
    state.anniversaries = Array.isArray(state.anniversaries) ? state.anniversaries : [];
    state.tags = Array.isArray(state.tags) ? state.tags : [];
    state.notebooks = Array.isArray(state.notebooks) ? state.notebooks : ['小本子'];
    state.settings = state.settings || {};
    state.profile = state.profile || { nickname: '我', avatar: '🌿' };
    var rm = state.settings.reminder;
    if (!rm || typeof rm !== 'object') {
      state.settings.reminder = { enabled: true, time: '21:00' };
    } else {
      if (typeof rm.enabled !== 'boolean') rm.enabled = true;
      if (!rm.time) rm.time = '21:00';
    }
    if (!state.version) state.version = 1;
    return state;
  }

  /* ---------------- 对外接口 ---------------- */
  var Store = {
    seed: seed,
    dateStr: dateStr,
    timeStr: timeStr,
    parseDate: parseDate,
    dayDiff: dayDiff,
    uid: uid,
    normalize: normalize,

    load: function () {
      if (memory) return Promise.resolve(memory);
      idbFailed = false;
      return idbGet(KEY).then(function (val) {
        mode = 'idb';
        if (val) { memory = normalize(val); return memory; }
        var ls = lsGet();
        if (ls) { memory = normalize(ls); return memory; }
        memory = seed();
        return Store.save(memory).then(function () { return memory; });
      }).catch(function () {
        mode = 'ls';
        var ls = lsGet();
        memory = normalize(ls) || seed();
        Store.save(memory);
        return memory;
      });
    },

    save: function (state) {
      memory = state;
      state.meta = state.meta || {};
      state.meta.updatedAt = new Date().toISOString();
      return idbSet(KEY, JSON.parse(JSON.stringify(state))).then(function () {
        return true;
      }).catch(function () {
        return lsSet(state);
      });
    },

    replaceAll: function (state) {
      memory = normalize(state);
      return Store.save(memory);
    },

    mode: function () { return mode; },

    isPersistent: function () {
      return mode === 'idb';
    },

    clear: function () {
      memory = null;
      return idbSet(KEY, null).catch(function () { }).then(function () {
        try { global.localStorage.removeItem(LS_KEY); } catch (e) { }
      });
    }
  };

  global.Store = Store;
})(window);
